#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Upload this repository to GitHub (Linux / macOS / Git Bash on Windows).
#
# Usage:
#   bash upload_to_github.sh <github-username> [repo-name] [public|private]
# Example:
#   bash upload_to_github.sh gauravkumar-dsu Multiscale-GTN-SDN public
#
# Two routes, chosen automatically:
#   A) GitHub CLI `gh` installed and logged in (`gh auth login`):
#      the repository is created for you and pushed in one step.
#   B) No `gh`: first create an EMPTY repository at https://github.com/new
#      (no README, no .gitignore, no licence), then run this script. When git
#      asks for a password, paste a Personal Access Token
#      (GitHub > Settings > Developer settings > Personal access tokens,
#      scope "repo"), not your account password.
# ---------------------------------------------------------------------------
set -euo pipefail
cd "$(dirname "$0")"

USER_NAME="${1:-}"
REPO="${2:-Multiscale-GTN-SDN}"
VIS="${3:-public}"
if [[ -z "$USER_NAME" ]]; then
  read -rp "GitHub username: " USER_NAME
fi
command -v git >/dev/null || { echo "git is not installed: https://git-scm.com/downloads"; exit 1; }

# identity for the commit (only set locally if missing)
git config user.name  >/dev/null 2>&1 || git config --global user.name  "$USER_NAME"
git config user.email >/dev/null 2>&1 || { read -rp "Email for git commits: " EMAIL; git config --global user.email "$EMAIL"; }

# put the GitHub URL into README / CITATION placeholders
URL="https://github.com/${USER_NAME}/${REPO}"
for f in README.md CITATION.cff; do
  [[ -f "$f" ]] && sed -i.bak "s#https://github.com/<your-username>/Multiscale-GTN-SDN#${URL}#g" "$f" && rm -f "$f.bak"
done
grep -q "^repository-code:" CITATION.cff || echo "repository-code: \"${URL}\"" >> CITATION.cff

if [[ ! -d .git ]]; then
  git init
fi
git checkout -B main
git add -A
git commit -m "Multiscale GTN-SDN: code, configs, reproducibility package and demo results" || echo "(nothing new to commit)"

if command -v gh >/dev/null && gh auth status >/dev/null 2>&1; then
  if gh repo view "${USER_NAME}/${REPO}" >/dev/null 2>&1; then
    git remote remove origin 2>/dev/null || true
    git remote add origin "${URL}.git"
    git push -u origin main
  else
    gh repo create "${USER_NAME}/${REPO}" --"${VIS}" --source . --remote origin --push \
      --description "Multiscale Graph Transformer Network for dynamic traffic engineering in SDN (HHSAD + parallel GTN + GCN + DDPG)"
  fi
else
  echo "GitHub CLI not available/logged in -> make sure ${URL} exists and is EMPTY, then press Enter."
  read -r _
  git remote remove origin 2>/dev/null || true
  git remote add origin "${URL}.git"
  git push -u origin main
fi
echo "Done: ${URL}"
