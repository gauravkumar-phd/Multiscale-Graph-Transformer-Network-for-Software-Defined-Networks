# Throughput (Mbps) — 20 paired runs from the reviewer response

| Model              |   N |   Mean |   Median |    Std | 95% CI           |
|:-------------------|----:|-------:|---------:|-------:|:-----------------|
| Multiscale GTN-SDN |  20 | 109.6  |   109.6  | 0.2168 | [109.52, 109.72] |
| MPNN               |  20 |  92.84 |    92.82 | 0.12   | [92.78, 92.90]   |
| CGC                |  20 |  88.95 |    88.95 | 0.1503 | [88.88, 89.02]   |
| GIN                |  20 |  84.21 |    84.22 | 0.1795 | [84.13, 84.29]   |
| MixHop             |  20 |  79.12 |    79.1  | 0.2099 | [79.02, 79.22]   |

| Compared Model               |   N pairs |   Mean Diff |   SD Diff | 95% CI Diff    |   t-value |   p-value (t-test) |   p-value (Wilcoxon) |   Cohen's d_z |   Hedges' g_av |   Holm Threshold |    P-Holm | Holm reject H0   | Direction       | Significant   |
|:-----------------------------|----------:|------------:|----------:|:---------------|----------:|-------------------:|---------------------:|--------------:|---------------:|-----------------:|----------:|:-----------------|:----------------|:--------------|
| Multiscale GTN-SDN vs MPNN   |        20 |       16.78 |    0.2526 | [16.66, 16.9]  |     297   |          2.64e-36  |            1.907e-06 |         66.41 |          93.85 |          0.05    | 2.64e-36  | Yes              | proposed better | Yes           |
| Multiscale GTN-SDN vs CGC    |        20 |       20.67 |    0.2244 | [20.56, 20.77] |     411.9 |          5.298e-39 |            8.832e-05 |         92.1  |         108.6  |          0.025   | 1.06e-38  | Yes              | proposed better | Yes           |
| Multiscale GTN-SDN vs GIN    |        20 |       25.41 |    0.2483 | [25.29, 25.53] |     457.7 |          7.131e-40 |            1.907e-06 |        102.4  |         125.1  |          0.01667 | 2.655e-39 | Yes              | proposed better | Yes           |
| Multiscale GTN-SDN vs MixHop |        20 |       30.5  |    0.2969 | [30.36, 30.64] |     459.5 |          6.638e-40 |            8.845e-05 |        102.7  |         140.1  |          0.0125  | 2.655e-39 | Yes              | proposed better | Yes           |