# Verification of reported tables (manuscript V3)

| Location | Metric | Reported | Recomputed | Source values |
|---|---|---|---|---|
| MPNN | Execution Time (ms) | 19.43 | 19.79 | 18.34, 19.12, 19.88, 20.64, 20.97 |
| MPNN (Table 2) | Execution Time (ms) | 19.43 | 19.79 | Table 4 average |

All other Average rows of Table 4 match the mean of their per-size rows (to 2 d.p.).