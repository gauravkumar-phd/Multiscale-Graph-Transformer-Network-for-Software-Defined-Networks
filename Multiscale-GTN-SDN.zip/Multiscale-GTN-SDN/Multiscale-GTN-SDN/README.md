# Multiscale GTN-SDN

**Multiscale Graph Transformer Network for Optimized Dynamic Traffic Engineering in Software Defined Networks**
Gaurav Kumar, Girisha Gowda Shivappa, Shamanth Nagaraju (IJIES manuscript)

This repository is the machine-readable reproducibility package for the paper:
source code, environment specification, simulator configuration,
topology/traffic generators, the exact seed list, tuning spaces and selected
values, baseline configurations, train/validation/test definitions, run-level
metrics, and scripts that rebuild Tables 2–5 plus the additional analyses the
reviewers requested (generalisation/robustness, common-budget sensitivity,
paired statistics, execution-time/energy protocol).

Repository: https://github.com/<your-username>/Multiscale-GTN-SDN

---

## 1. Pipeline

```
live telemetry ──► X_t (N×8 → 64)   A_t (residual-bandwidth weighted)
                         │                 │
                         │      HHSAD: 1-hop {A} | 2-hop Â²⊙M⁽²⁾ | multi-hop Σₖ Âᵏ⊙M⁽ᵏ⁾, k=3..K_max   (Eq. 1, ε-sparsified)
                         │                 │
                         ├──► GTN-1 ──┐    │  three parallel GTN branches, unshared weights,
                         ├──► GTN-2 ──┼─ Σ │  C = 4 meta-path channels, 3 GTN layers (Eqs. 2–5)
                         └──► GTN-3 ──┘    │  element-wise sum aggregation (Eq. 6)
                                   ▼
                     channel-wise GCN 64→32→16 (2 624 params), concat over C → Z  (Eq. 7)
                                   ▼
       state S = [per-candidate pooled Z ⊕ path telemetry] × K=4 (Yen) ⊕ z_src ⊕ z_dst ⊕ demand
                                   ▼
             DDPG actor (256,128) → masked split ratios → OpenFlow select-group bucket weights
             DDPG critic (256,128), MSBE loss (Eq. 9), policy gradient (Eq. 10), soft targets (Eq. 11)
             reward R = −w₁·Delay − w₂·Loss + w₃·Throughput, (w₁,w₂,w₃) = (0.4,0.4,0.2)  (Eq. 8)
```

| Paper element | Code |
|---|---|
| Graph state G_t=(V,E,X_t), min-max features → 64-d | `mgtn_sdn/features.py`, `models/encoders.py` (`inp`) |
| HHSAD, hop-disjoint mask M⁽ᵏ⁾, threshold ε (Eq. 1) | `mgtn_sdn/hhsad.py` |
| GTN soft selection + meta-path composition (Eqs. 2–5) | `mgtn_sdn/models/gtn.py` |
| Aggregation (Eq. 6) + channel-wise GCN (Eq. 7) | `models/encoders.py::MultiscaleGTNEncoder`, `models/gcn.py` |
| Yen K=4 loop-free candidates + lookup mask | `mgtn_sdn/paths.py` |
| DDPG head, Gaussian noise σ=0.2 decaying ×0.995 (Eqs. 9–11) | `mgtn_sdn/rl/ddpg.py`, `mgtn_sdn/agent.py` |
| Reward (Eq. 8), termination (2 500 requests or link loss ≥ 50 %) | `mgtn_sdn/simulator.py`, `mgtn_sdn/trainer.py` |
| Model selection (rolling reward, window 5, patience 10) | `mgtn_sdn/trainer.py::train_policy` |
| Table 1 hyper-parameters | `configs/default.yaml` |

## 2. Reviewer comments → where they are addressed

| Reviewer request | What the package provides | Files |
|---|---|---|
| Reproducible, defensible baseline protocol (implementation source, parameter spaces, tuning criteria, initialisation, stopping rules, exact modifications) | Every baseline re-implemented from its paper; per-baseline parameter space, defaults, initialisation, validation criterion, stopping rule and the exact adaptation + justification, all machine-readable; seeded random search with an identical trial budget; trial logs and selected values saved | `mgtn_sdn/baselines/*.py`, `configs/baselines.yaml`, `scripts/run_baselines.py`, `results/*/tuning/` |
| Distinguish faithful re-implementations from modified variants; algorithm-appropriate tuning **and** common-budget sensitivity | `implementation_type` field (all five are *adapted* variants, each with `native` / `modification` / `justification`); independent tuning per algorithm; sensitivity of every baseline to the tuning budget (10/25/50/100 trials) | `configs/baselines.yaml`, `scripts/run_budget_sensitivity.py`, Table 7 |
| MPNN average execution time inconsistent (19.43 vs 19.79 ms) | Automated check of every Table 4 "Average" row and the Table 2 ↔ Table 4 link; MPNN is the only mismatch → 19.79 ms. Generated tables compute averages from per-size rows, so this cannot recur | `scripts/verify_reported_tables.py`, `results/verification/` |
| "Solid statistical evidence" unsupported; run-level values, paired tests, CIs, effect sizes | Run-level CSV for every run; paired t-test, Wilcoxon signed-rank, Holm correction, Cohen's d_z, Hedges' g_av, 95 % CI of the difference; the 20-run throughput analysis from the response letter is reproduced exactly | `mgtn_sdn/stats.py`, `scripts/statistical_tests.py`, `data/reported/throughput_runs_reviewer_response.csv`, `results/stats_reviewer_response/` |
| Machine-readable reproducibility package (code, environment, simulator config, seeds, tuning spaces, baselines, splits, run-level metrics, scripts for Tables 2–5) | This repository | everything; see §4–§6 |
| Independent generalisation test (held-out topology family, distribution shift, link failures) | Models trained only on BA + Poisson, then evaluated frozen on Waxman and Watts–Strogatz topologies, bursty MMPP/Pareto/hotspot traffic and 5 %/10 % link failures, with % change vs in-distribution. Real topologies (e.g. Internet Topology Zoo GraphML) can be plugged in with `--topology file` | `scripts/run_generalization.py`, `mgtn_sdn/topology.py`, `mgtn_sdn/traffic.py`, Table 6 |
| Ablation must isolate HHSAD vs capacity vs RL head | 18 explicit factor settings incl. capacity-matched "Parallel GTN (Without HHSAD)", masking-only, decomposition-only, channel / hop-cap / ε sweeps, GCN refinement without RL, static shortest path; parameter count logged per variant | `configs/ablation.yaml`, `scripts/run_ablation.py`, Table 3 |
| Define execution-time boundary and energy methodology | Boundary = observation arrival → preprocessing → encoder → action → candidate-path evaluation → bucket weights (transmission/forwarding excluded); 20 warm-up + 1 000 measured decisions per run, `perf_counter_ns`; energy E = (P_active − P_idle)·t via Intel RAPL, with a documented TDP×utilisation fallback whose use is written next to every number | `mgtn_sdn/profiling.py`, `mgtn_sdn/trainer.py`, `scripts/measure_latency_energy.py`, Table 8 |

## 3. Installation

Python ≥ 3.10 (tested with 3.11, CPU only; no GPU needed).

```bash
git clone https://github.com/<your-username>/Multiscale-GTN-SDN.git
cd Multiscale-GTN-SDN
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt                        # exact versions: requirements-lock.txt
python -m pytest -q                                     # 11 unit tests
```
or `conda env create -f environment.yml && conda activate mgtn-sdn`.

## 4. Running

### Quick demo (≈ 1.5–2 h on 2 CPU cores) — produces `results/quick/`
```bash
bash scripts/run_quick.sh            # WORKERS=2 by default
```
Same code and protocol as the full run with smaller networks (40/60/80 nodes),
12 episodes × 300 requests, 400-request test trace and a 6-trial tuning budget
(`configs/quick.yaml`). **These numbers exercise the pipeline; they are not the
paper-scale results.**

### Full paper protocol — produces `results/full/`
```bash
WORKERS=8 bash scripts/run_full.sh
```
200–1000 nodes, 5 seeds, 100 episodes × 2 500 requests, 50-trial tuning budget.
Paper-scale training is expensive (Table 1 reports 34.8 min per episode on an
i5-13400), so run the stages on a multi-core machine; every script resumes from
its CSV and can be sharded (`--shard i --nshards n`).

### Individual stages
```bash
python scripts/verify_reported_tables.py                           # checks the manuscript tables
python scripts/run_main.py            [--override configs/quick.yaml]   # Tables 2 & 4
python scripts/run_ablation.py        --sizes 200                       # Table 3
python scripts/run_baselines.py       --stage tune                      # per-baseline tuning (budget 50)
python scripts/run_baselines.py       --stage eval                      # Table 5
python scripts/run_budget_sensitivity.py --sizes 200                    # Table 7
python scripts/run_generalization.py                                     # Table 6
python scripts/measure_latency_energy.py                                 # Table 8
python scripts/tune_proposed.py --what eps | --what weights              # ε and reward-weight grids
python scripts/make_tables.py                                            # rebuild all tables/figures
python scripts/statistical_tests.py                                      # paired statistics
python scripts/train.py --method proposed --nodes 200 --seed 42          # single model + checkpoint
python scripts/evaluate.py --ckpt results/full/checkpoints/proposed_n200_s42.pt --topology waxman
```

## 5. Experimental protocol (identical for every method)

| Item | Setting |
|---|---|
| Seeds | 42, 128, 256, 512, 728 (topology, weights, exploration) |
| Topology | NSFNET-like 14-node/21-link seed grown by Barabási–Albert (m = 2) to 200–1000 nodes; 150 Mbps links, 1–5 ms propagation. 200 nodes → 393 links, 1000 nodes → 1 993 links |
| Traffic | Poisson arrivals (25 req/s at 200 nodes, scaled linearly with N), exponential holding (mean 4 s), uniform source/destination, uniform 10–60 Mbps demands |
| Train / validation / test | training episode *e* uses traffic seed 1000·s + e; validation trace 1000·s + 998 (tuning only, topology seed 7); test trace 1000·s + 999 (never seen in training or tuning) |
| Candidate paths | Yen K = 4 loop-free shortest paths, unavailable slots masked |
| Data plane | flow-level discrete-event simulator; each link an M/M/1/K queue (K = 1000 packets, 1500 B) → loss, queueing delay; propagation delay per hop |
| Metrics | packet loss (%), end-to-end delay (ms), delivered throughput per request (Mbps), workload per node (Jain index of per-switch load, %), link utilisation of used links (%), decision time (ms) |
| Tuning budget | 50 validation trials per baseline (independent spaces); ε and reward weights of the proposed model by grid search |
| Statistics | run-level CSV; paired by (size, seed) cell; t-test + Wilcoxon + Holm; d_z, g_av, 95 % CI |

## 6. Outputs

```
results/<run>/runs/*.csv          run-level metrics (one row per model × size × seed [× scenario])
results/<run>/tables/*.csv        Tables 2–8 as CSV
results/<run>/RESULTS.md          all tables in Markdown
results/<run>/figures/*.png       comparison and scalability figures
results/<run>/stats/*.md|csv      paired statistics per metric
results/<run>/tuning/             trial logs + selected hyper-parameters per baseline
results/<run>/logs/               per-worker logs + config/environment snapshot (JSON)
results/verification/             manuscript table check (MPNN 19.79 ms)
results/stats_reviewer_response/  reproduction of the 20-run throughput statistics
```

## 7. Demo results (`results/quick`, reduced scale)

Produced by `scripts/run_quick.sh` on a 2-core CPU in about 1.5 h:
40/60/80-node BA topologies, 5 seeds, 12 training episodes × 300 requests,
400-request test trace, 6-trial tuning budget. All tables and figures are in
[`results/quick/RESULTS.md`](results/quick/RESULTS.md) and `results/quick/figures/`.

**Read these numbers as a check that the pipeline runs end to end. They are not the paper-scale
results.** At this scale and training budget the proposed model does **not**
separate from the graph baselines. Paired tests over 15 (size × seed) cells
find no significant packet-loss difference against MixHop, GIN, CGC or MPNN.
The analytic/heuristic baselines CAHPO and HGPO, and DERFDRL, reach lower loss
(Holm-corrected p < 0.05, proposed worse). CAHPO's PSO fitness uses the same
M/M/1/K model as the simulator, which gives it a strong advantage in this environment.
The proposed encoder is also the slowest per decision (≈ 6 ms at 40–80 nodes,
≈ 33 ms at 1000 nodes on this CPU). Paper-scale conclusions require
`scripts/run_full.sh`.

Graph baselines (Table 2 protocol, macro-average over sizes, mean ± SD over seeds):

| Model                       | Packet Loss (%) ↓   | End-to-End Delay (ms) ↓   | Throughput (Mbps) ↑   | Execution Time (ms) ↓   |
|:----------------------------|:--------------------|:--------------------------|:----------------------|:------------------------|
| MixHop                      | 0.45±0.35           | 14.20±2.80                | 34.62±0.72            | 2.38±0.42               |
| GIN                         | 0.92±0.80           | 17.11±4.56                | 34.42±0.62            | 2.02±0.05               |
| CGC                         | 1.80±2.44           | 21.61±9.80                | 34.08±0.53            | 2.36±0.21               |
| MPNN                        | 0.79±0.39           | 15.28±1.54                | 34.47±0.79            | 2.62±0.12               |
| Proposed Multiscale GTN-SDN | 0.62±0.26           | 16.12±2.32                | 34.53±0.61            | 6.19±0.15               |

Re-implemented baselines (Table 5 protocol):

| Model                       | Packet Loss (%) ↓   | End-to-End Delay (ms) ↓   | Throughput (Mbps) ↑   | Execution Time (ms) ↓   |
|:----------------------------|:--------------------|:--------------------------|:----------------------|:------------------------|
| CAHPO [19]                  | 0.09±0.06           | 10.40±0.65                | 34.76±0.70            | 2.42±0.05               |
| D2DQN [20]                  | 0.40±0.16           | 15.09±1.71                | 34.62±0.73            | 0.55±0.03               |
| HGPO [21]                   | 0.06±0.03           | 11.95±0.43                | 34.77±0.71            | 0.43±0.10               |
| DSENN [22]                  | 0.93±0.36           | 17.04±1.82                | 34.43±0.70            | 0.25±0.09               |
| DERFDRL [23]                | 0.16±0.10           | 12.47±0.94                | 34.73±0.70            | 0.72±0.08               |
| Proposed Multiscale GTN-SDN | 0.62±0.26           | 16.12±2.32                | 34.53±0.61            | 6.19±0.15               |

![comparison](results/quick/figures/fig_table2_comparison.png)
![scalability](results/quick/figures/fig_table4_scalability.png)
![generalisation](results/quick/figures/fig_table6_generalization.png)

### Checks on the manuscript's reported numbers (`results/verification/`, `results/stats_reviewer_response/`)
* Table 4 MPNN execution-time average: the rows 18.34, 19.12, 19.88, 20.64, 20.97 average to
  **19.79 ms** (reported 19.43 ms in Table 4 and Table 2). No other Average row is inconsistent.
* The 20-run throughput statistics in the response letter are reproduced exactly (e.g. vs MPNN:
  mean diff 16.779, t = 297.01, p = 2.64e-36, Holm-adjusted p = 2.64e-36, d_z = 66.41). Wilcoxon
  signed-rank p-values are added as a non-parametric check.


## 8. Implementation notes

* **Data plane.** Experiments use an analytic flow-level simulator (M/M/1/K
  links) so 1000-node runs fit on a CPU. `ryu_app/gtn_ryu_controller.py` is an
  OpenFlow 1.3 integration template that installs the same decisions as
  select-group bucket weights on Ryu/Mininet. It is provided for deployment and
  was **not** used to produce any number in `results/`.
* **GTN without N×N products.** Meta-path adjacencies are applied as sparse
  operators (the per-layer row normalisations telescope), and the C channels are
  processed together with a block-diagonal operator. The result is identical
  to the dense formulation (unit test `test_gtn_operator_matches_dense_metapath`).
* **Multi-hop candidates.** The multi-hop branch receives the hop-disjoint pools
  k = 3…K_max as separate GTN candidates, so its soft selection weights play the
  role of w_k.
* **HHSAD pool density.** With the paper's symmetric normalisation and ε = 0.05,
  Âᵏ entries shrink quickly on scale-free graphs: on the 200-node topology the
  2-hop pool keeps 820 of 4 290 distance-2 pairs, the 3-hop pool 14 entries,
  and the 4- and 5-hop pools are empty (1000 nodes: 3 724 / 34 / 0 / 0).
  `encoder_kw.hhsad_norm: rw` (random-walk normalisation) is available as an
  option. `hhsad.py` logs pool sizes (`stats`) for every topology.
* **Training details.** AdamW (decoupled weight decay 1e-4; L2-coupled Adam
  collapsed the actor to uniform splits). The actor scores each candidate slot
  with the same (256,128) MLP (no bias toward slot 1), with centred logits
  bounded by 3·tanh. The encoder is trained end-to-end through the actor's
  action; the critic sees a detached state.
* **"Without RL" rows.** `myopic` = the same encoder with a supervised one-step
  reward regressor (no bootstrapping, critic or exploration); `shortest` = all
  traffic on the first Yen path.

## 9. Uploading to GitHub

```bash
bash upload_to_github.sh <github-username> Multiscale-GTN-SDN public       # Linux / macOS / Git Bash
```
```powershell
powershell -ExecutionPolicy Bypass -File .\upload_to_github.ps1 -User <github-username>   # Windows
```
With the GitHub CLI (`gh auth login`) the repository is created and pushed
automatically. Without it, create an **empty** repository at
https://github.com/new first; use a Personal Access Token as the password.
Both scripts also replace the `<your-username>` placeholders in this README.

## 10. Citation & licence

See `CITATION.cff`. Code released under the MIT licence (`LICENSE`).
