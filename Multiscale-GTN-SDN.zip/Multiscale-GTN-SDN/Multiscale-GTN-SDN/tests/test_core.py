"""Unit tests: python -m pytest -q"""
import sys
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mgtn_sdn.agent import bucket_weights  # noqa: E402
from mgtn_sdn.hhsad import hhsad_decompose  # noqa: E402
from mgtn_sdn.models.gcn import ChannelGCN, count_parameters  # noqa: E402
from mgtn_sdn.models.gtn import GTNBranch  # noqa: E402
from mgtn_sdn.paths import CandidatePaths  # noqa: E402
from mgtn_sdn.simulator import SDNSimulator, mm1k  # noqa: E402
from mgtn_sdn.stats import paired_comparison  # noqa: E402
from mgtn_sdn.topology import barabasi_albert_nsfnet, fail_links, held_out_topology  # noqa: E402
from mgtn_sdn.traffic import make_traffic  # noqa: E402


def small_graph():
    return nx.to_scipy_sparse_array(nx.cycle_graph(8))


def test_hhsad_pools_are_hop_disjoint():
    A = small_graph()
    pools = hhsad_decompose(A, k_max=4, eps=0.0, mask=True)
    from scipy.sparse.csgraph import shortest_path
    D = shortest_path(A, unweighted=True)
    two = pools.two_hop.to_dense().numpy()
    assert np.all(D[two > 0] == 2)
    for k, P in zip(range(3, 5), pools.multi_hop):
        assert np.all(D[P.to_dense().numpy() > 0] == k)


def test_hhsad_threshold_prunes():
    A = small_graph()
    dense = hhsad_decompose(A, k_max=3, eps=0.0)
    sparse = hhsad_decompose(A, k_max=3, eps=0.2)
    assert sparse.two_hop._nnz() <= dense.two_hop._nnz()
    assert torch.all(sparse.two_hop.values() > 0.2)


def test_gtn_operator_matches_dense_metapath():
    torch.manual_seed(0)
    n = 6
    A = torch.rand(n, n) * (torch.rand(n, n) > 0.5)
    As = A.to_sparse().coalesce()
    g = GTNBranch(n_candidates=2, n_layers=3, channels=2)
    alpha = g.selection_weights().detach()
    for c in range(2):
        Q = [alpha[l, c, 0] * A + alpha[l, c, 1] * torch.eye(n) for l in range(4)]
        P = Q[0] @ Q[1] @ Q[2] @ Q[3]
        rs = P.sum(1, keepdim=True)
        ref = torch.where(rs > 0, P / rs.clamp(min=1e-12), torch.zeros_like(P))
        got = g.metapath_matrix([As, None], n, c).detach()
        assert torch.allclose(got, ref, atol=1e-5)


def test_gcn_parameter_count_matches_table1():
    assert count_parameters(ChannelGCN(64, 32, 16)) == 2624


def test_mm1k_limits():
    P, L = mm1k(np.array([0.0, 0.5, 0.999999, 2.0]), 1000)
    assert P[0] == 0 and P[1] < 1e-12
    assert abs(P[3] - 0.5) < 1e-6           # overload 2x -> half the packets dropped
    assert 0 < L[2] <= 1000 and abs(L[3] - 999) < 2


def test_candidate_paths_loop_free_and_k4():
    topo = barabasi_albert_nsfnet(60, seed=1)
    cp = CandidatePaths(topo.graph, k=4)
    for s, d in [(0, 59), (3, 40), (10, 11)]:
        ps = cp.get(s, d)
        assert 1 <= len(ps) <= 4
        assert all(len(set(p)) == len(p) for p in ps)
        assert cp.mask(s, d).sum() == len(ps)


def test_simulator_releases_all_bandwidth():
    topo = barabasi_albert_nsfnet(40, seed=3)
    reqs = make_traffic("poisson", 40, 200, 5, base_rate=15, ref_nodes=40)
    sim = SDNSimulator(topo, reqs, loss_break=None)
    while sim.current_request() is not None:
        sim.step(np.array([0.5, 0.5, 0, 0]))
    sim._release_until(1e12)
    assert np.allclose(sim.load, 0, atol=1e-6)


def test_topology_sizes_and_failures():
    t = barabasi_albert_nsfnet(200, m=2, seed=42)
    assert t.n == 200 and nx.is_connected(t.graph)
    w = held_out_topology("waxman", 100, seed=1)
    assert nx.is_connected(w.graph)
    f = fail_links(t, 0.1, seed=1)
    assert f.graph.number_of_edges() < t.graph.number_of_edges() and nx.is_connected(f.graph)


def test_bucket_weights_sum_to_100():
    w = bucket_weights(np.array([0.333, 0.333, 0.334, 0.0]))
    assert w.sum() == 100 and w[3] == 0


def test_reviewer_throughput_statistics_reproduced():
    df = pd.read_csv(ROOT / "data/reported/throughput_runs_reviewer_response.csv")
    res = paired_comparison(df["Multiscale GTN-SDN"].values, {"MPNN": df["MPNN"].values})
    assert res["t-value"].iloc[0] == pytest.approx(297.007119, rel=1e-5)
    assert res["Cohen's d_z"].iloc[0] == pytest.approx(66.412811, rel=1e-5)


def test_reported_mpnn_average_is_19_79():
    t4 = pd.read_csv(ROOT / "data/reported/table4_reported_V3.csv", dtype={"Nodes": str})
    m = t4[(t4["Model"] == "MPNN") & (t4["Nodes"] != "Average")]["Execution Time (ms)"].mean()
    assert round(m, 2) == 19.79
