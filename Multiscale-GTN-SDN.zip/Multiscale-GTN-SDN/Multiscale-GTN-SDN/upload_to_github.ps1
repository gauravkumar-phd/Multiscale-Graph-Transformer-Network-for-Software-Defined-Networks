# ---------------------------------------------------------------------------
# Upload this repository to GitHub from Windows PowerShell.
#
# Usage (in PowerShell, inside the Multiscale-GTN-SDN folder):
#   powershell -ExecutionPolicy Bypass -File .\upload_to_github.ps1 -User <github-username>
#   powershell -ExecutionPolicy Bypass -File .\upload_to_github.ps1 -User gauravkumar-dsu -Repo Multiscale-GTN-SDN -Visibility private
#
# Route A: GitHub CLI (winget install GitHub.cli ; gh auth login) -> repo is created and pushed.
# Route B: without gh, first create an EMPTY repo at https://github.com/new, then run this.
#          When asked for a password use a Personal Access Token (scope "repo").
# ---------------------------------------------------------------------------
param(
  [Parameter(Mandatory = $true)][string]$User,
  [string]$Repo = "Multiscale-GTN-SDN",
  [ValidateSet("public", "private")][string]$Visibility = "public"
)
$ErrorActionPreference = "Continue"   # git writes progress to stderr; check $LASTEXITCODE instead
Set-Location -Path $PSScriptRoot

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  Write-Host "git is not installed. Install it from https://git-scm.com/download/win (or: winget install Git.Git)"; exit 1
}
if (-not (git config user.name))  { git config --global user.name $User }
if (-not (git config user.email)) { $e = Read-Host "Email for git commits"; git config --global user.email $e }

$Url = "https://github.com/$User/$Repo"
foreach ($f in @("README.md", "CITATION.cff")) {
  if (Test-Path $f) {
    (Get-Content $f -Raw -Encoding UTF8).Replace("https://github.com/<your-username>/Multiscale-GTN-SDN", $Url) |
      Set-Content $f -Encoding UTF8 -NoNewline
  }
}
if (-not (Select-String -Path CITATION.cff -Pattern "^repository-code:" -Quiet)) {
  Add-Content CITATION.cff "repository-code: `"$Url`""
}

if (-not (Test-Path .git)) { git init }
git checkout -B main
git add -A
git commit -m "Multiscale GTN-SDN: code, configs, reproducibility package and demo results"

$haveGh = (Get-Command gh -ErrorAction SilentlyContinue) -and ((gh auth status 2>&1) -match "Logged in")
if ($haveGh) {
  gh repo view "$User/$Repo" *> $null
  if ($LASTEXITCODE -eq 0) {
    git remote remove origin 2>$null; git remote add origin "$Url.git"; git push -u origin main
  } else {
    gh repo create "$User/$Repo" "--$Visibility" --source . --remote origin --push `
      --description "Multiscale Graph Transformer Network for dynamic traffic engineering in SDN (HHSAD + parallel GTN + GCN + DDPG)"
  }
} else {
  Read-Host "GitHub CLI not available/logged in. Make sure $Url exists and is EMPTY, then press Enter"
  git remote remove origin 2>$null
  git remote add origin "$Url.git"
  git push -u origin main
}
if ($LASTEXITCODE -ne 0) { Write-Host "Push failed - check the repository exists, is empty, and your token has 'repo' scope."; exit 1 }
Write-Host "Done: $Url"
