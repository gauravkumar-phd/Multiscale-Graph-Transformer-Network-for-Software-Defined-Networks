"""Regenerate Tables 2-5 (and the reviewer-requested extra tables) from the
run-level CSVs in <output_dir>/runs, plus figures.

Aggregation rules (fixes the MPNN-average inconsistency by construction)
    Table 4  per (model, size): mean over seeds; 'Average' row = arithmetic
             mean of the five per-size means (never typed by hand)
    Table 2  per model: per-seed macro-average over sizes, then mean +/- SD
             over seeds -> the Table 2 mean equals the Table 4 'Average' row
    Table 3  per variant: mean +/- SD over seeds (single size)
    Table 5  re-implemented baselines + proposed, same macro rule as Table 2
    Extra    generalisation/robustness (+ % change vs in-distribution),
             common-budget sensitivity, execution time + energy

    python scripts/make_tables.py --override configs/quick.yaml
"""
import argparse
import glob
import sys
from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mgtn_sdn.utils import load_config  # noqa: E402

COLS = {"packet_loss": "Packet Loss (%) ↓", "delay": "End-to-End Delay (ms) ↓", "throughput": "Throughput (Mbps) ↑",
        "workload": "Workload per Node (Avg) (%) ↑", "link_util": "Link Utilization (%) ↑",
        "exec_ms": "Execution Time (ms) ↓"}
PROPOSED = "Proposed Multiscale GTN-SDN"
ORDER_MAIN = ["MixHop", "GIN", "CGC", "MPNN", PROPOSED]
ORDER_B = ["CAHPO [19]", "D2DQN [20]", "HGPO [21]", "DSENN [22]", "DERFDRL [23]", PROPOSED]
# validated categorical palette (fixed slot order; see README 'Figures')
COLOR = {PROPOSED: "#2a78d6", "MPNN": "#eb6834", "CGC": "#1baf7a", "GIN": "#eda100", "MixHop": "#e87ba4",
         "CAHPO [19]": "#eb6834", "D2DQN [20]": "#1baf7a", "HGPO [21]": "#eda100", "DSENN [22]": "#e87ba4",
         "DERFDRL [23]": "#008300"}
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e6e5e0"


def load(run_dir, name):
    files = sorted(glob.glob(str(run_dir / f"{name}.shard*.csv")))
    return pd.concat([pd.read_csv(f) for f in files], ignore_index=True) if files else None


def pm(m, s, d=2):
    return f"{m:.{d}f}±{s:.{d}f}" if np.isfinite(s) else f"{m:.{d}f}"


def macro_table(df, order):
    per_seed = df.groupby(["model", "seed"])[list(COLS)].mean()          # macro over sizes, per seed
    rows = []
    for m in [o for o in order if o in per_seed.index.get_level_values(0)]:
        g = per_seed.loc[m]
        rows.append({"Model": m, **{COLS[k]: pm(g[k].mean(), g[k].std(ddof=1)) for k in COLS}})
    return pd.DataFrame(rows)


def scalability_table(df, order):
    rows = []
    for m in [o for o in order if o in set(df["model"])]:
        g = df[df["model"] == m].groupby("nodes")[list(COLS)].mean()
        for n, r in g.iterrows():
            rows.append({"Model": m, "Nodes": int(n), **{COLS[k]: round(r[k], 2) for k in COLS}})
        rows.append({"Model": m, "Nodes": "Average", **{COLS[k]: round(g[k].mean(), 2) for k in COLS}})
    return pd.DataFrame(rows)


def style(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=MUTED, labelsize=8)
    ax.grid(axis="x", color=GRID, lw=0.8)
    ax.set_axisbelow(True)


def bar_panels(df, order, path, title):
    per_seed = df.groupby(["model", "seed"])[list(COLS)].mean()
    models = [o for o in order if o in per_seed.index.get_level_values(0)]
    fig, axes = plt.subplots(2, 3, figsize=(13, 6.2), facecolor="#fcfcfb")
    for ax, k in zip(axes.ravel(), COLS):
        mu = [per_seed.loc[m][k].mean() for m in models]
        sd = [per_seed.loc[m][k].std(ddof=1) for m in models]
        y = np.arange(len(models))
        ax.barh(y, mu, xerr=sd, color=[COLOR.get(m, "#2a78d6") for m in models], height=0.62,
                error_kw=dict(ecolor=MUTED, lw=1, capsize=2), edgecolor="#fcfcfb", linewidth=2)
        for yi, v, e in zip(y, mu, sd):
            ax.text(v + (e if np.isfinite(e) else 0), yi, f"  {v:.2f}", va="center", fontsize=8, color=INK)
        ax.set_yticks(y, [m.replace("Proposed Multiscale GTN-SDN", "Proposed") for m in models], fontsize=8)
        ax.set_title(COLS[k], fontsize=9, color=INK, loc="left")
        ax.set_facecolor("#fcfcfb")
        ax.margins(x=0.22)
        ax.set_xlim(left=0)
        style(ax)
    fig.suptitle(title, fontsize=11, color=INK, x=0.01, ha="left")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def scal_lines(df, order, path, title):
    models = [o for o in order if o in set(df["model"])]
    fig, axes = plt.subplots(2, 3, figsize=(13, 6.2), facecolor="#fcfcfb")
    for ax, k in zip(axes.ravel(), COLS):
        for m in models:
            g = df[df["model"] == m].groupby("nodes")[k].mean()
            ax.plot(g.index, g.values, lw=2, marker="o", ms=5, color=COLOR.get(m), label=m,
                    markeredgecolor="#fcfcfb", markeredgewidth=1.5)
        ax.set_title(COLS[k], fontsize=9, color=INK, loc="left")
        ax.set_xlabel("Nodes", fontsize=8, color=MUTED)
        ax.set_facecolor("#fcfcfb")
        style(ax)
        ax.grid(axis="y", color=GRID, lw=0.8)
    h, lab = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, lab, loc="lower center", ncol=len(models), frameon=False, fontsize=8)
    fig.suptitle(title, fontsize=11, color=INK, x=0.01, ha="left")
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    fig.savefig(path, dpi=150)
    plt.close(fig)


def gen_fig(gen, path):
    models = [m for m in [PROPOSED, "MPNN", "DERFDRL [23]"] if m in set(gen["model"])]
    scen = [s for s in gen["scenario"].drop_duplicates() if s != "id"]
    fig, axes = plt.subplots(1, 2, figsize=(12, 3.8), facecolor="#fcfcfb")
    for ax, (k, lab) in zip(axes, (("packet_loss", "Packet loss change vs in-distribution (pp)"),
                                   ("throughput", "Throughput change vs in-distribution (%)"))):
        w = 0.8 / len(models)
        for i, m in enumerate(models):
            ref = gen[(gen["model"] == m) & (gen["scenario"] == "id")][k].mean()
            vals = [gen[(gen["model"] == m) & (gen["scenario"] == s)][k].mean() for s in scen]
            vals = [v - ref for v in vals] if k == "packet_loss" else [100 * (v - ref) / ref for v in vals]
            x = np.arange(len(scen)) + (i - (len(models) - 1) / 2) * w
            ax.bar(x, vals, w * 0.92, color=COLOR.get(m), label=m.replace(PROPOSED, "Proposed"))
        ax.axhline(0, color=MUTED, lw=0.8)
        ax.set_xticks(np.arange(len(scen)), scen, fontsize=8)
        ax.set_title(lab, fontsize=9, color=INK, loc="left")
        ax.set_facecolor("#fcfcfb")
        style(ax)
        ax.grid(axis="x", visible=False); ax.grid(axis="y", color=GRID, lw=0.8)
    axes[0].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", default=str(ROOT / "configs/default.yaml"))
    p.add_argument("--override", default=None)
    a = p.parse_args()
    cfg = load_config(a.config, a.override)
    base = ROOT / cfg["output_dir"]
    run_dir, tdir, fdir = base / "runs", base / "tables", base / "figures"
    tdir.mkdir(parents=True, exist_ok=True); fdir.mkdir(parents=True, exist_ok=True)
    md = [f"# Results — {cfg['output_dir']}", "",
          f"Seeds: {cfg['seeds']} | sizes: {cfg['node_sizes']} | episodes: {cfg['training']['episodes']} x "
          f"{cfg['simulation']['requests_per_episode']} requests | eval: {cfg['simulation']['eval_requests']} requests", ""]

    def emit(df, name, title):
        df.to_csv(tdir / f"{name}.csv", index=False)
        md.extend([f"## {title}", "", df.to_markdown(index=False), ""])

    main_df = load(run_dir, "main")
    if main_df is not None:
        emit(macro_table(main_df, ORDER_MAIN), "table2_main_comparison",
             "Table 2. Macro-average comparison with graph baselines (mean ± SD over seeds)")
        emit(scalability_table(main_df, ORDER_MAIN), "table4_scalability",
             "Table 4. Scalability (mean over seeds; Average = mean of per-size means)")
        bar_panels(main_df, ORDER_MAIN, fdir / "fig_table2_comparison.png", "Macro-average comparison (error bars: SD over seeds)")
        scal_lines(main_df, ORDER_MAIN, fdir / "fig_table4_scalability.png", "Scalability across network sizes")

    ab = load(run_dir, "ablation")
    if ab is not None:
        order = ab.sort_values("order")["model"].drop_duplicates().tolist()
        rows = []
        for m in order:
            g = ab[ab["model"] == m]
            rows.append({"Model": m, "Params": int(g["params"].iloc[0]),
                         **{COLS[k]: pm(g[k].mean(), g[k].std(ddof=1)) for k in COLS}})
        emit(pd.DataFrame(rows), "table3_ablation",
             f"Table 3. Targeted ablation ({int(ab['nodes'].iloc[0])} nodes, seeds {sorted(ab['seed'].unique().tolist())})")

    bl = load(run_dir, "baselines")
    if bl is not None:
        df5 = pd.concat([bl, main_df[main_df["model"] == PROPOSED]]) if main_df is not None else bl
        emit(macro_table(df5, ORDER_B), "table5_reimplemented", "Table 5. Re-implemented baselines (macro-average, mean ± SD over seeds)")
        bar_panels(df5, ORDER_B, fdir / "fig_table5_reimplemented.png", "Re-implemented baselines (error bars: SD over seeds)")
        tsel = sorted(glob.glob(str(base / "tuning" / "*_selected.json")))
        if tsel:
            import json
            sel = [json.loads(Path(f).read_text()) for f in tsel]
            emit(pd.DataFrame([{"Baseline": s["method"], "Budget": s["budget"], "Validation reward": round(s["best_score"], 3),
                                "Selected values": ", ".join(f"{k}={v:.4g}" if isinstance(v, float) else f"{k}={v}"
                                                             for k, v in s["selected"].items())} for s in sel]),
                 "table5b_tuning_selected", "Table 5b. Independently tuned baseline parameters (validation topology seed 7)")

    gen = load(run_dir, "generalization")
    if gen is not None:
        # relative change is computed from scenario means (a per-seed ratio explodes when the
        # in-distribution loss is ~0); packet loss is additionally given in percentage points
        rows = []
        for (m, sc), g in gen.groupby(["model", "scenario"], sort=False):
            r = {"Model": m, "Scenario": sc, **{COLS[k]: pm(g[k].mean(), g[k].std(ddof=1)) for k in COLS}}
            ref = gen[(gen["model"] == m) & (gen["scenario"] == "id")]
            if sc != "id":
                r["Δ loss (pp)"] = round(g["packet_loss"].mean() - ref["packet_loss"].mean(), 2)
                for k, lab in (("delay", "Δ delay (%)"), ("throughput", "Δ throughput (%)"), ("link_util", "Δ link util (%)")):
                    r[lab] = round(100 * (g[k].mean() - ref[k].mean()) / ref[k].mean(), 1)
            rows.append(r)
        emit(pd.DataFrame(rows), "table6_generalization",
             "Table 6. Generalisation / robustness (trained on BA + Poisson only; no re-tuning)")
        gen_fig(gen, fdir / "fig_table6_generalization.png")

    sens = load(run_dir, "sensitivity")
    if sens is not None:
        rows = []
        for (m, b), g in sens.groupby(["model", "budget"]):
            rows.append({"Model": m, "Tuning budget (trials)": int(b), "Validation reward": round(g["val_score"].mean(), 3),
                         **{COLS[k]: pm(g[k].mean(), g[k].std(ddof=1)) for k in ("packet_loss", "delay", "throughput")}})
        emit(pd.DataFrame(rows), "table7_budget_sensitivity", "Table 7. Common-budget sensitivity of re-implemented baselines")

    prof = load(run_dir, "profiling")
    if prof is not None:
        rows = []
        for (m, n), g in prof.groupby(["model", "nodes"], sort=False):
            rows.append({"Model": m, "Nodes": int(n), "Runs": len(g),
                         "Decision time (ms)": pm(g["exec_ms_mean"].mean(), g["exec_ms_mean"].std(ddof=1), 3),
                         "p95 (ms)": round(g["exec_ms_p95"].mean(), 3),
                         "Energy / step (J)": f"{g['energy_j_per_step'].mean():.2e}",
                         "Energy method": g["energy_method"].iloc[0]})
        emit(pd.DataFrame(rows), "table8_latency_energy", "Table 8. Controller decision time and per-step energy")

    (base / "RESULTS.md").write_text("\n".join(md), encoding="utf-8")
    print(f"wrote {base / 'RESULTS.md'}")


if __name__ == "__main__":
    main()
