"""Shared CLI plumbing for the experiment scripts."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mgtn_sdn.utils import environment_info, get_logger, load_config, save_json  # noqa: E402


def parser(desc: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=desc)
    p.add_argument("--config", default=str(ROOT / "configs/default.yaml"))
    p.add_argument("--override", default=None, help="e.g. configs/quick.yaml")
    p.add_argument("--seeds", type=int, nargs="*", default=None)
    p.add_argument("--sizes", type=int, nargs="*", default=None)
    p.add_argument("--shard", type=int, default=0, help="this worker's index")
    p.add_argument("--nshards", type=int, default=1, help="number of parallel workers")
    p.add_argument("--threads", type=int, default=1, help="torch intra-op threads per worker")
    return p


def setup(args, name: str):
    torch.set_num_threads(args.threads)
    cfg = load_config(args.config, args.override)
    seeds = args.seeds or cfg["seeds"]
    sizes = args.sizes or cfg["node_sizes"]
    out = ROOT / cfg["output_dir"]
    out.mkdir(parents=True, exist_ok=True)
    log = get_logger(f"{name}.{args.shard}", out / "logs" / f"{name}.shard{args.shard}.log")
    save_json({"config": cfg, "environment": environment_info(), "argv": sys.argv},
              out / "logs" / f"{name}.shard{args.shard}.meta.json")
    return cfg, seeds, sizes, out, log


def my_cells(cells, args):
    return [c for i, c in enumerate(cells) if i % args.nshards == args.shard]


def shard_csv(out: Path, name: str, args) -> Path:
    return out / "runs" / f"{name}.shard{args.shard}.csv"
