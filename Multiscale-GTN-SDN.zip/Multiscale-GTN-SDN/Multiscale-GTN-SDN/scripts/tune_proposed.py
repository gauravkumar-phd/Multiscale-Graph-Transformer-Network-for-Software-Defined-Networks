"""Grid search for the proposed model's HHSAD sparsification threshold
(eps in [0.01, 0.10], step 0.01) and reward weights (w1, w2, w3 in
[0.2, 0.8], step 0.1, summing to 1) on the validation topology (seed 7) and
validation trace (seed 1000*7 + 998) — never on test seeds.

Because candidate reward weightings define different reward scales, every
configuration is scored with the SAME yardstick: the validation reward
computed with equal weights (1/3, 1/3, 1/3); raw metrics are logged too.

    python scripts/tune_proposed.py --override configs/quick.yaml --what eps
    python scripts/tune_proposed.py --what weights
"""
import itertools

import numpy as np
import pandas as pd
from _common import my_cells, parser, setup

from mgtn_sdn.experiment import build_method, make_topology
from mgtn_sdn.simulator import reward_from_metrics
from mgtn_sdn.trainer import evaluate_policy, train_policy
from mgtn_sdn.utils import deep_update, set_seed

VAL = 7


def score(cfg, n):
    set_seed(VAL)
    topo = make_topology(cfg, n, VAL)
    pol = build_method("proposed", cfg, VAL)
    train_policy(pol, topo, cfg, VAL)
    res = evaluate_policy(pol, topo, cfg, VAL, traffic_seed=1000 * VAL + 998)
    yard = reward_from_metrics({"delay": res["delay"], "loss": res["packet_loss"], "throughput": res["throughput"]},
                               (1 / 3, 1 / 3, 1 / 3), cfg["simulation"]["reward_norm"])
    return yard, res


def main():
    p = parser(__doc__)
    p.add_argument("--what", choices=["eps", "weights"], default="eps")
    args = p.parse_args()
    cfg, _, sizes, out, log = setup(args, f"tune_proposed_{args.what}")
    n = sizes[0]
    if args.what == "eps":
        grid = [{"model": {"encoder_kw": {"eps": e}}} for e in cfg["tuning"]["eps_grid"]]
    else:
        g = cfg["reward"]["grid"]
        vals = np.round(np.arange(g["low"], g["high"] + 1e-9, g["step"]), 2)
        grid = [{"reward": {"weights": [float(a), float(b), float(round(1 - a - b, 2))]}}
                for a, b in itertools.product(vals, vals) if g["low"] - 1e-9 <= 1 - a - b <= g["high"] + 1e-9]
    rows = []
    for ov in my_cells(grid, args):
        y, res = score(deep_update(cfg, ov), n)
        rows.append({"override": str(ov), "yardstick_reward": y, **{k: res[k] for k in ("packet_loss", "delay", "throughput")}})
        log.info(f"{ov} -> {y:.4f}")
    df = pd.DataFrame(rows).sort_values("yardstick_reward", ascending=False)
    (out / "tuning").mkdir(parents=True, exist_ok=True)
    df.to_csv(out / "tuning" / f"proposed_{args.what}_grid.shard{args.shard}.csv", index=False)
    print(df.head(10).to_string(index=False))


if __name__ == "__main__":
    main()
