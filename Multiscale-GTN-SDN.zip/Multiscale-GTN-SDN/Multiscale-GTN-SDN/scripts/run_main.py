"""Tables 2 and 4 — proposed Multiscale GTN-SDN vs graph baselines
(MixHop, GIN, CGC, MPNN) under the unified setting (same simulator, traffic,
candidate paths, DDPG head, seeds), for every network size and seed.
Writes run-level rows to <output_dir>/runs/main.shard*.csv.

    python scripts/run_main.py --override configs/quick.yaml --shard 0 --nshards 2
"""
from _common import my_cells, parser, setup, shard_csv

from mgtn_sdn.experiment import DISPLAY, append_rows, done_keys, run_cell


def main():
    p = parser(__doc__)
    p.add_argument("--methods", nargs="*", default=None)
    args = p.parse_args()
    cfg, seeds, sizes, out, log = setup(args, "main")
    methods = args.methods or (cfg["graph_baselines"] + ["proposed"])
    csv = shard_csv(out, "main", args)
    done = done_keys(csv)
    cells = [(m, n, s) for n in sizes for s in seeds for m in methods]
    for m, n, s in my_cells(cells, args):
        if (DISPLAY.get(m, m), str(n), str(s)) in done:
            continue
        log.info(f"[main] {m} nodes={n} seed={s}")
        row = run_cell(m, cfg, n, s)
        append_rows(row, csv)
        log.info(f"   -> loss {row['packet_loss']:.3f}%  delay {row['delay']:.2f} ms  thr {row['throughput']:.2f}  "
                 f"exec {row['exec_ms']:.2f} ms  ({row['train_s']} s)")


if __name__ == "__main__":
    main()
