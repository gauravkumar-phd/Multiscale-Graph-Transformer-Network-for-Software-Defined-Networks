"""Execution-time and per-step energy measurement (reviewer request).

Boundary: observation arrival -> preprocessing -> encoder -> action selection
-> candidate-path evaluation -> forwarding decision (bucket weights).
Protocol: 20 warm-up + 1000 measured decisions per run, one run per seed,
monotonic perf_counter_ns clock. Energy E = (P_active - P_idle) * t using
Intel RAPL when readable, otherwise a documented TDP x utilisation estimate
(method is written to the output). Timing does not depend on trained weights,
so freshly initialised models are profiled on a network in steady state.

    python scripts/measure_latency_energy.py --override configs/quick.yaml --sizes 200 1000
"""
import numpy as np
import pandas as pd
import torch
from _common import parser, setup

from mgtn_sdn.agent import bucket_weights
from mgtn_sdn.experiment import DISPLAY, build_method, make_topology
from mgtn_sdn.profiling import energy_per_step, idle_power, measure
from mgtn_sdn.simulator import SDNSimulator
from mgtn_sdn.traffic import make_traffic
from mgtn_sdn.utils import set_seed


def main():
    p = parser(__doc__)
    p.add_argument("--methods", nargs="*", default=None)
    args = p.parse_args()
    cfg, seeds, sizes, out, log = setup(args, "profiling")
    pc = cfg["profiling"]
    methods = args.methods or (["proposed"] + cfg["graph_baselines"] + cfg["reimplemented_baselines"])
    p_idle = idle_power(pc["idle_seconds"])
    rows = []
    for n in sizes:
        for s in seeds:
            set_seed(s)
            topo = make_topology(cfg, n, s)
            sc = cfg["simulation"]
            reqs = make_traffic(sc["traffic"], n, pc["warmup"] + pc["measured"] + 400, 1000 * s + 997, **sc["traffic_kw"])
            for m in methods:
                sim = SDNSimulator(topo, reqs, k_paths=sc["k_paths"], buffer_pkts=sc["buffer_pkts"], loss_break=None)
                pol = build_method(m, cfg, s)
                pol.begin_topology(sim)
                for _ in range(400):                      # bring the network to steady state (shortest path)
                    sim.step(np.eye(sim.k)[0])
                state = {"i": sim.t_idx}

                def decide():
                    req = reqs[state["i"] % len(reqs)]
                    state["i"] += 1
                    split = pol.act(sim, req, False)
                    mask = sim.mask(req.src, req.dst)
                    split = split * mask
                    bucket_weights(split / split.sum() if split.sum() > 0 else mask / mask.sum())

                with torch.no_grad():
                    mres = measure(decide, pc["warmup"], pc["measured"])
                e = energy_per_step(mres, pc["measured"], pc["cpu_tdp_watts"], p_idle)
                row = {"model": DISPLAY.get(m, m), "nodes": n, "seed": s, **mres, **e}
                rows.append(row)
                log.info(f"[prof] {m} n={n} s={s}: {mres['exec_ms_mean']:.3f} +/- {mres['exec_ms_std']:.3f} ms, "
                         f"E={e['energy_j_per_step']:.5f} J ({e['energy_method']})")
    df = pd.DataFrame(rows)
    (out / "runs").mkdir(exist_ok=True, parents=True)
    df.to_csv(out / "runs" / f"profiling.shard{args.shard}.csv", index=False)


if __name__ == "__main__":
    main()
