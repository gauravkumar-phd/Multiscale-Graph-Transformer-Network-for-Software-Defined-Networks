"""Train one model on one (size, seed) cell and save a checkpoint.

    python scripts/train.py --method proposed --nodes 200 --seed 42
    python scripts/train.py --method proposed --nodes 40 --seed 42 --override configs/quick.yaml
Checkpoint: <output_dir>/checkpoints/<method>_n<nodes>_s<seed>.pt
"""
import torch
from _common import parser, setup

from mgtn_sdn.experiment import build_method, make_topology
from mgtn_sdn.trainer import evaluate_policy, train_policy
from mgtn_sdn.utils import save_json, set_seed


def main():
    p = parser(__doc__)
    p.add_argument("--method", default="proposed")
    p.add_argument("--nodes", type=int, default=200)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()
    cfg, _, _, out, log = setup(args, "train")
    set_seed(args.seed)
    topo = make_topology(cfg, args.nodes, args.seed)
    log.info(f"topology: {topo.meta}")
    pol = build_method(args.method, cfg, args.seed)
    hist = train_policy(pol, topo, cfg, args.seed, log=log.info)
    res = evaluate_policy(pol, topo, cfg, args.seed)
    log.info(f"test: {res}")
    ck = out / "checkpoints" / f"{args.method}_n{args.nodes}_s{args.seed}.pt"
    ck.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"method": args.method, "nodes": args.nodes, "seed": args.seed, "state": pol.state_dict(),
                "config": cfg}, ck)
    save_json({"history": hist, "test": res}, ck.with_suffix(".json"))
    log.info(f"saved {ck}")


if __name__ == "__main__":
    main()
