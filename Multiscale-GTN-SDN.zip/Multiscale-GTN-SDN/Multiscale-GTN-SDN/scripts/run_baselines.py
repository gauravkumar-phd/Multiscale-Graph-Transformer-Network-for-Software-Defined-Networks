"""Table 5 — re-implemented baselines (CAHPO, D2DQN, HGPO, DSENN, DERFDRL).

Step 1 (tuning, --stage tune): each baseline is tuned independently in its own
parameter space (configs/baselines.yaml) with the same validation budget
(cfg.tuning.budget). Tuning uses a dedicated validation topology (seed 7, not a
test seed) and a validation traffic trace; the score is the cumulative
validation reward (Eq. 8). Trial logs + selected values are saved.

Step 2 (evaluation, --stage eval): the tuned configuration is trained and
evaluated on every (size, seed) cell with the shared protocol.

    python scripts/run_baselines.py --override configs/quick.yaml --stage tune
    python scripts/run_baselines.py --override configs/quick.yaml --stage eval --shard 0 --nshards 2
"""
import json

import pandas as pd
from _common import ROOT, my_cells, parser, setup, shard_csv

from mgtn_sdn.experiment import DISPLAY, append_rows, build_method, done_keys, make_topology, run_cell
from mgtn_sdn.trainer import evaluate_policy, train_policy
from mgtn_sdn.tuning import random_search
from mgtn_sdn.utils import deep_update, load_yaml, save_json, set_seed

VAL_TOPO_SEED = 7


def tune(name, spec, cfg, budget, size, tune_episodes, log, seed=VAL_TOPO_SEED):
    tcfg = deep_update(cfg, {"training": {"episodes": tune_episodes}})

    def objective(params):
        set_seed(seed)
        topo = make_topology(tcfg, size, seed)
        pol = build_method(name, tcfg, seed, params)
        train_policy(pol, topo, tcfg, seed)
        res = evaluate_policy(pol, topo, tcfg, seed, traffic_seed=1000 * seed + 998)
        return res["reward"]

    best, score, trials = random_search(spec["space"], objective, budget, seed=seed, defaults=spec.get("defaults"))
    log.info(f"[tune] {name}: best score {score:.3f} with {best}")
    return best, score, trials


def main():
    p = parser(__doc__)
    p.add_argument("--stage", choices=["tune", "eval", "both"], default="both")
    p.add_argument("--methods", nargs="*", default=None)
    p.add_argument("--tune-size", type=int, default=None)
    p.add_argument("--tune-episodes", type=int, default=None)
    args = p.parse_args()
    cfg, seeds, sizes, out, log = setup(args, "baselines")
    spec = load_yaml(ROOT / "configs/baselines.yaml")
    methods = args.methods or cfg["reimplemented_baselines"]
    tdir = out / "tuning"
    tdir.mkdir(parents=True, exist_ok=True)
    tune_size = args.tune_size or sizes[0]
    tune_eps = args.tune_episodes or max(2, cfg["training"]["episodes"] // 4)

    if args.stage in ("tune", "both"):
        for m in my_cells(methods, args):
            best, score, trials = tune(m, spec[m], cfg, cfg["tuning"]["budget"], tune_size, tune_eps, log)
            pd.DataFrame(trials).to_csv(tdir / f"{m}_trials.csv", index=False)
            save_json({"method": m, "budget": cfg["tuning"]["budget"], "validation_topology_seed": VAL_TOPO_SEED,
                       "validation_size": tune_size, "tuning_episodes": tune_eps, "best_score": score,
                       "selected": best}, tdir / f"{m}_selected.json")

    if args.stage in ("eval", "both"):
        csv = shard_csv(out, "baselines", args)
        done = done_keys(csv)
        cells = [(m, n, s) for n in sizes for s in seeds for m in methods]
        for m, n, s in my_cells(cells, args):
            if (DISPLAY[m], str(n), str(s)) in done:
                continue
            sel = tdir / f"{m}_selected.json"
            params = json.loads(sel.read_text())["selected"] if sel.exists() else spec[m].get("defaults", {})
            log.info(f"[baseline] {m} nodes={n} seed={s} params={params}")
            row = run_cell(m, cfg, n, s, params=params)
            append_rows(row, csv)
            log.info(f"   -> loss {row['packet_loss']:.3f}%  delay {row['delay']:.2f} ms  thr {row['throughput']:.2f}")


if __name__ == "__main__":
    main()
