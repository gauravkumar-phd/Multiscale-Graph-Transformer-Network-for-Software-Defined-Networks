"""Generalisation and robustness evaluation (reviewer request).

Each model is trained ONLY on the in-distribution setting (Barabasi-Albert,
Poisson traffic) and then evaluated, with frozen parameters and no further
tuning (same HHSAD threshold, reward weights, candidate-path config and
model-selection rule), on:
    id            in-distribution test trace (reference)
    topo:<family> strictly held-out topology families (Waxman, Watts-Strogatz)
    traffic:bursty  MMPP ON/OFF bursts, Pareto holding times, hotspot matrix
    fail:<p>      p fraction of links disabled during inference
Relative degradation vs the in-distribution result is reported in %.

    python scripts/run_generalization.py --override configs/quick.yaml
"""
import json

from _common import my_cells, parser, setup, shard_csv

from mgtn_sdn.experiment import append_rows, run_cell
from mgtn_sdn.topology import fail_links, held_out_topology
from mgtn_sdn.trainer import evaluate_policy

METRICS = ["packet_loss", "delay", "throughput", "workload", "link_util", "exec_ms"]


def main():
    p = parser(__doc__)
    p.add_argument("--methods", nargs="*", default=["proposed", "mpnn", "derfdrl"])
    args = p.parse_args()
    cfg, seeds, _, out, log = setup(args, "generalization")
    g = cfg["generalization"]
    sizes = args.sizes or g["sizes"]
    csv = shard_csv(out, "generalization", args)
    tdir = out / "tuning"
    for m, n, s in my_cells([(m, n, s) for n in sizes for s in seeds for m in args.methods], args):
        params = None
        sel = tdir / f"{m}_selected.json"
        if sel.exists():
            params = json.loads(sel.read_text())["selected"]
        row, pol, topo = run_cell(m, cfg, n, s, params=params, return_policy=True, extra={"scenario": "id"})
        ref = {k: row[k] for k in METRICS}
        rows = [row]
        cap = cfg["topology"]["link_capacity_mbps"]
        scenarios = [(f"topo:{fam}", held_out_topology(fam, n, cap, seed=s), None) for fam in g["held_out_families"]]
        scenarios.append((f"traffic:{g['shifted_traffic']}", topo, g["shifted_traffic"]))
        scenarios += [(f"fail:{f:.2f}", fail_links(topo, f, seed=s), None) for f in g["link_failure_fractions"]]
        for name, t, traffic in scenarios:
            res = evaluate_policy(pol, t, cfg, s, traffic=traffic)
            r = {**{k: v for k, v in row.items() if k not in METRICS + ["eval_reward", "steps", "exec_ms_std"]},
                 **{k: res[k] for k in METRICS}, "scenario": name, "eval_reward": res["reward"],
                 "topo_nodes": t.meta["nodes"], "topo_edges": t.meta["edges"]}
            for k in METRICS:
                r[f"{k}_change_pct"] = 100 * (res[k] - ref[k]) / ref[k] if ref[k] else float("nan")
            rows.append(r)
            log.info(f"[gen] {m} n={n} s={s} {name}: loss {res['packet_loss']:.3f}% delay {res['delay']:.2f} "
                     f"thr {res['throughput']:.2f}")
        append_rows(rows, csv)


if __name__ == "__main__":
    main()
