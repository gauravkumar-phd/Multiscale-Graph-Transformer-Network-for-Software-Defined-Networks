#!/usr/bin/env bash
# Reduced-scale end-to-end demo (results/quick). Two parallel workers.
# Same code and protocol as the full run; smaller sizes / episodes / budgets.
set -euo pipefail
cd "$(dirname "$0")/.."
O="--override configs/quick.yaml"
W=${WORKERS:-2}
par() {  # run a script on $W shards in parallel
  for i in $(seq 0 $((W-1))); do python scripts/"$1" $O --shard $i --nshards $W "${@:2}" & done; wait
}
python scripts/verify_reported_tables.py
python scripts/statistical_tests.py --reviewer-throughput data/reported/throughput_runs_reviewer_response.csv \
       --outdir results/stats_reviewer_response
par run_main.py
par run_baselines.py --stage tune
par run_baselines.py --stage eval
par run_ablation.py --sizes 40 --seeds 42 128 256
par run_generalization.py
par run_budget_sensitivity.py --sizes 40 --seeds 42 128 256
python scripts/measure_latency_energy.py $O --sizes 200 1000 --seeds 42 128 256
python scripts/make_tables.py $O
python scripts/statistical_tests.py $O
