"""Consistency check of the manuscript's reported tables (reviewer comment:
MPNN average execution time).

* Recomputes every 'Average' row of Table 4 from its five per-size rows.
* Cross-checks the Table 2 macro-averages against the recomputed Table 4
  averages and Table 5 / Table 3 proposed rows against Table 2.
* Writes corrected CSVs (table2_corrected.csv, table4_corrected.csv) and a
  report listing every mismatch (> 0.01 after rounding to 2 d.p.).

    python scripts/verify_reported_tables.py
"""
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / "data" / "reported"
OUT = ROOT / "results" / "verification"


def mean_part(x: str) -> float:
    return float(str(x).split("±")[0].strip())


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    t4 = pd.read_csv(D / "table4_reported_V3.csv", dtype={"Nodes": str})
    t2 = pd.read_csv(D / "table2_reported_V3.csv")
    metrics = [c for c in t4.columns if c not in ("Model", "Nodes")]
    lines, t4c = ["# Verification of reported tables (manuscript V3)", ""], t4.copy()
    mismatches = []
    for model, g in t4.groupby("Model", sort=False):
        per = g[g["Nodes"] != "Average"]
        avg_idx = g.index[g["Nodes"] == "Average"][0]
        for m in metrics:
            calc = round(per[m].astype(float).mean() + 1e-12, 2)
            rep = float(t4.loc[avg_idx, m])
            if abs(calc - rep) > 0.011:
                mismatches.append((model, m, rep, calc, ", ".join(f"{v:g}" for v in per[m])))
                t4c.loc[avg_idx, m] = calc
    t4c.to_csv(OUT / "table4_corrected.csv", index=False)

    # Table 2 must equal the (corrected) Table 4 averages
    t2c = t2.copy()
    for i, r in t2.iterrows():
        avg = t4c[(t4c["Model"] == r["Model"]) & (t4c["Nodes"] == "Average")]
        for m in metrics:
            rep = mean_part(r[m])
            calc = float(avg[m].iloc[0])
            if abs(rep - calc) > 0.011:
                sd = str(r[m]).split("±")[1] if "±" in str(r[m]) else ""
                mismatches.append((r["Model"] + " (Table 2)", m, rep, calc, "Table 4 average"))
                t2c.loc[i, m] = f"{calc:.2f}±{sd}" if sd else f"{calc:.2f}"
    t2c.to_csv(OUT / "table2_corrected.csv", index=False)

    t5 = pd.read_csv(D / "table5_reported_V3.csv")
    t3 = pd.read_csv(D / "table3_reported_reviewer_response.csv")
    prop2 = t2[t2["Model"].str.startswith("Proposed")].iloc[0]
    for name, t in (("Table 5", t5), ("Table 3", t3)):
        row = t[t["Model"].str.startswith("Proposed")].iloc[0]
        for m in metrics:
            if abs(mean_part(row[m]) - mean_part(prop2[m])) > 0.011:
                mismatches.append((f"Proposed ({name})", m, mean_part(row[m]), mean_part(prop2[m]), "Table 2"))

    if mismatches:
        lines += ["| Location | Metric | Reported | Recomputed | Source values |", "|---|---|---|---|---|"]
        lines += [f"| {a} | {b} | {c:.2f} | {d:.2f} | {e} |" for a, b, c, d, e in mismatches]
    else:
        lines.append("No mismatches found.")
    lines += ["", "All other Average rows of Table 4 match the mean of their per-size rows (to 2 d.p.)."]
    (OUT / "verification_report.md").write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
