"""Run-level statistical analysis (reviewer comments on statistical support).

Mode A — reviewer-response data (20 paired throughput runs, wide CSV):
    python scripts/statistical_tests.py --reviewer-throughput data/reported/throughput_runs_reviewer_response.csv

Mode B — this repository's own run-level results (results/<run>/runs/*.csv):
    python scripts/statistical_tests.py --override configs/quick.yaml
    For every metric the proposed model is compared with every other model on
    the same (nodes, seed) cells: pairing subject = seed x topology instance
    x traffic trace shared by both models.

Outputs: descriptive table (N, mean, median, SD, 95% CI), paired t-test,
Wilcoxon signed-rank, Holm-corrected p, Cohen's d_z, Hedges' g_av, CI of
the mean difference — as CSV and Markdown.
"""
import argparse
import glob
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mgtn_sdn.stats import descriptive_table, paired_comparison  # noqa: E402
from mgtn_sdn.utils import load_config  # noqa: E402

METRICS = {"packet_loss": False, "delay": False, "throughput": True, "workload": True,
           "link_util": True, "exec_ms": False}
PROPOSED = "Proposed Multiscale GTN-SDN"


def fmt(df):
    out = df.copy()
    for c in out.columns:
        if out[c].dtype.kind == "f":
            out[c] = out[c].map(lambda v: f"{v:.4g}")
    return out


def reviewer_mode(path, outdir):
    df = pd.read_csv(path)
    models = [c for c in df.columns if c != "run"]
    ref = models[0]
    desc = descriptive_table({m: df[m].values for m in models})
    comp = paired_comparison(df[ref].values, {m: df[m].values for m in models[1:]}, label=ref,
                             higher_is_better=True)
    outdir.mkdir(parents=True, exist_ok=True)
    desc.to_csv(outdir / "throughput_descriptive.csv", index=False)
    comp.to_csv(outdir / "throughput_paired_tests.csv", index=False)
    md = ["# Throughput (Mbps) — 20 paired runs from the reviewer response", "",
          fmt(desc).to_markdown(index=False), "", fmt(comp).to_markdown(index=False)]
    (outdir / "throughput_stats.md").write_text("\n".join(md), encoding="utf-8")
    print("\n".join(md))


def repo_mode(cfg, outdir):
    run_dir = ROOT / cfg["output_dir"] / "runs"
    for group in ("main", "baselines"):
        files = sorted(glob.glob(str(run_dir / f"{group}.shard*.csv")))
        if not files:
            continue
        df = pd.concat([pd.read_csv(f) for f in files])
        if group == "baselines":                        # compare against the proposed runs of the main study
            mains = sorted(glob.glob(str(run_dir / "main.shard*.csv")))
            if mains:
                m = pd.concat([pd.read_csv(f) for f in mains])
                df = pd.concat([df, m[m["model"] == PROPOSED]])
        md = [f"# Paired statistics — {group} study ({cfg['output_dir']})", "",
              "Pairing subject: (network size, seed) cell — both models share topology, "
              "training traces and test trace.", ""]
        for metric, hib in METRICS.items():
            wide = df.pivot_table(index=["nodes", "seed"], columns="model", values=metric)
            if PROPOSED not in wide:
                continue
            wide = wide.dropna()
            others = {c: wide[c].values for c in wide.columns if c != PROPOSED}
            desc = descriptive_table({c: wide[c].values for c in wide.columns})
            comp = paired_comparison(wide[PROPOSED].values, others, label="Proposed", higher_is_better=hib)
            desc.to_csv(outdir / f"{group}_{metric}_descriptive.csv", index=False)
            comp.to_csv(outdir / f"{group}_{metric}_paired_tests.csv", index=False)
            md += [f"## {metric} ({'higher' if hib else 'lower'} is better)", "",
                   fmt(desc).to_markdown(index=False), "", fmt(comp).to_markdown(index=False), ""]
        (outdir / f"{group}_stats.md").write_text("\n".join(md), encoding="utf-8")
        print(f"wrote {outdir / f'{group}_stats.md'}")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--reviewer-throughput", default=None)
    p.add_argument("--config", default=str(ROOT / "configs/default.yaml"))
    p.add_argument("--override", default=None)
    p.add_argument("--outdir", default=None)
    a = p.parse_args()
    if a.reviewer_throughput:
        reviewer_mode(a.reviewer_throughput, Path(a.outdir or ROOT / "results" / "stats_reviewer_response"))
        return
    cfg = load_config(a.config, a.override)
    out = Path(a.outdir or ROOT / cfg["output_dir"] / "stats")
    out.mkdir(parents=True, exist_ok=True)
    repo_mode(cfg, out)


if __name__ == "__main__":
    main()
