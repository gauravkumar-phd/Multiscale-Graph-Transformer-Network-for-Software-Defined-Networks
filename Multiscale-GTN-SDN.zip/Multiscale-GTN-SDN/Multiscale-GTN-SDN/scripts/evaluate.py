"""Evaluate a saved checkpoint on the in-distribution test trace or on a
shifted scenario, without any re-training.

    python scripts/evaluate.py --ckpt results/full/checkpoints/proposed_n200_s42.pt
    python scripts/evaluate.py --ckpt ... --topology waxman
    python scripts/evaluate.py --ckpt ... --traffic bursty
    python scripts/evaluate.py --ckpt ... --fail 0.10
    python scripts/evaluate.py --ckpt ... --topology file --topology-file my_net.graphml
"""
import argparse
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mgtn_sdn.experiment import build_method, make_topology  # noqa: E402
from mgtn_sdn.topology import fail_links, held_out_topology  # noqa: E402
from mgtn_sdn.simulator import SDNSimulator  # noqa: E402
from mgtn_sdn.trainer import evaluate_policy  # noqa: E402
from mgtn_sdn.traffic import make_traffic  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--ckpt", required=True)
    p.add_argument("--topology", default="ba", help="ba | waxman | watts_strogatz | grid | file")
    p.add_argument("--topology-file", default=None)
    p.add_argument("--traffic", default=None, help="poisson | bursty")
    p.add_argument("--fail", type=float, default=0.0)
    a = p.parse_args()
    torch.set_num_threads(1)
    ck = torch.load(a.ckpt, weights_only=False)
    cfg, n, s = ck["config"], ck["nodes"], ck["seed"]
    pol = build_method(ck["method"], cfg, s)
    if a.topology == "ba":
        topo = make_topology(cfg, n, s)
    else:
        topo = held_out_topology(a.topology, n, cfg["topology"]["link_capacity_mbps"], seed=s, path=a.topology_file)
    if a.fail > 0:
        topo = fail_links(topo, a.fail, seed=s)
    # structural preparation for this topology, then load trained weights
    warm = SDNSimulator(topo, make_traffic("poisson", topo.n, 1, 0, **cfg["simulation"]["traffic_kw"]))
    pol.begin_topology(warm)
    pol.load_state_dict(ck["state"])
    res = evaluate_policy(pol, topo, cfg, s, traffic=a.traffic)
    print(json.dumps({"topology": topo.meta, "traffic": a.traffic or cfg["simulation"]["traffic"], **res}, indent=2,
                     default=float))


if __name__ == "__main__":
    main()
