"""Table 3 — targeted ablation (configs/ablation.yaml). Every variant is run
on the same size / seeds; the parameter count of each variant is recorded so
gains from hop-specific decomposition can be separated from added capacity.

    python scripts/run_ablation.py --override configs/quick.yaml --sizes 40
"""
from _common import ROOT, my_cells, parser, setup, shard_csv

from mgtn_sdn.experiment import append_rows, done_keys, run_cell
from mgtn_sdn.utils import load_yaml


def main():
    p = parser(__doc__)
    p.add_argument("--ablation", default=str(ROOT / "configs/ablation.yaml"))
    args = p.parse_args()
    cfg, seeds, sizes, out, log = setup(args, "ablation")
    variants = load_yaml(args.ablation)["variants"]
    csv = shard_csv(out, "ablation", args)
    done = done_keys(csv)
    cells = [(v, n, s) for n in sizes for s in seeds for v in variants]
    for v, n, s in my_cells(cells, args):
        if (v["name"], str(n), str(s)) in done:
            continue
        log.info(f"[ablation] {v['name']} nodes={n} seed={s}")
        row = run_cell(v["name"], cfg, n, s, label=v["name"], encoder=v["encoder"],
                       encoder_kw=v.get("kw", {}), head=v["head"],
                       extra={"order": variants.index(v)})
        append_rows(row, csv)
        log.info(f"   -> loss {row['packet_loss']:.3f}%  delay {row['delay']:.2f} ms  params {row['params']}")


if __name__ == "__main__":
    main()
