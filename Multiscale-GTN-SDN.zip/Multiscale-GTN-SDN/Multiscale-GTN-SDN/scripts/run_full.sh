#!/usr/bin/env bash
# Full paper-scale protocol (results/full): 200-1000 nodes, 5 seeds, 100 episodes
# x 2500 requests, 50-trial tuning budget. Expect days of CPU time; set WORKERS
# to the number of physical cores available.
set -euo pipefail
cd "$(dirname "$0")/.."
W=${WORKERS:-4}
par() {
  for i in $(seq 0 $((W-1))); do python scripts/"$1" --shard $i --nshards $W "${@:2}" & done; wait
}
python scripts/verify_reported_tables.py
par run_main.py
par run_baselines.py --stage tune
par run_baselines.py --stage eval
par run_ablation.py --sizes 200
par run_generalization.py
par run_budget_sensitivity.py --sizes 200
python scripts/measure_latency_energy.py
python scripts/make_tables.py
python scripts/statistical_tests.py
