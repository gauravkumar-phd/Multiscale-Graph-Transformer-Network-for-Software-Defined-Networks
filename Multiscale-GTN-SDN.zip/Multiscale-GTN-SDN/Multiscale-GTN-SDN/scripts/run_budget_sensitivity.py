"""Common-budget sensitivity analysis for Table 5 fairness.

For each re-implemented baseline and each tuning budget B in
cfg.tuning.sensitivity_budgets (paper protocol: 10, 25, 50, 100 trials) the
baseline is re-tuned with B validation trials and evaluated on the test
seeds. Shows whether the ranking depends on the 50-trial budget.

    python scripts/run_budget_sensitivity.py --override configs/quick.yaml --sizes 60 --seeds 42 128 256
"""
from _common import ROOT, my_cells, parser, setup, shard_csv

from mgtn_sdn.experiment import append_rows, run_cell
from mgtn_sdn.utils import load_yaml
from run_baselines import tune


def main():
    p = parser(__doc__)
    p.add_argument("--methods", nargs="*", default=None)
    p.add_argument("--tune-episodes", type=int, default=None)
    args = p.parse_args()
    cfg, seeds, sizes, out, log = setup(args, "sensitivity")
    spec = load_yaml(ROOT / "configs/baselines.yaml")
    methods = args.methods or cfg["reimplemented_baselines"]
    budgets = cfg["tuning"]["sensitivity_budgets"]
    n = sizes[0]
    tune_eps = args.tune_episodes or max(2, cfg["training"]["episodes"] // 4)
    csv = shard_csv(out, "sensitivity", args)
    for m, b in my_cells([(m, b) for m in methods for b in budgets], args):
        best, score, _ = tune(m, spec[m], cfg, b, n, tune_eps, log)
        for s in seeds:
            row = run_cell(m, cfg, n, s, params=best, extra={"budget": b, "val_score": score})
            append_rows(row, csv)
            log.info(f"[sens] {m} budget={b} seed={s} -> loss {row['packet_loss']:.3f}% thr {row['throughput']:.2f}")


if __name__ == "__main__":
    main()
