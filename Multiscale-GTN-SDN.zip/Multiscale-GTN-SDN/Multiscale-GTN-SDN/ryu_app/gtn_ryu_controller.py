"""Optional Ryu (OpenFlow 1.3) integration template for Multiscale GTN-SDN.

Deploys the learned traffic-splitting decision to real / Mininet switches:
    1. topology discovery (ryu.topology, run with --observe-links)
    2. port statistics every POLL_S seconds -> link utilisation telemetry
    3. on a new flow (packet-in) the trained policy returns K split ratios
    4. ratios -> integer weights of an OFPGT_SELECT group (bucket weights),
       installed at the ingress switch, plus a flow entry pointing to it;
       downstream hops of every candidate path get plain forwarding entries.

This file is NOT executed by the simulation experiments (they use the
analytic simulator in mgtn_sdn/simulator.py). Ryu needs Python <= 3.9, so use
a separate environment:
    pip install ryu==4.34 eventlet==0.30.2
    ryu-manager --observe-links ryu_app/gtn_ryu_controller.py
Set GTN_CKPT to a checkpoint produced by scripts/train.py.
"""
import os
import sys
from pathlib import Path

import networkx as nx
import numpy as np
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
from ryu.lib import hub
from ryu.lib.packet import ethernet, ipv4, packet
from ryu.ofproto import ofproto_v1_3
from ryu.topology import api as topo_api
from ryu.topology import event as topo_event

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
POLL_S = 2.0
LINK_MBPS = 150.0


class GTNController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.dps, self.g = {}, nx.Graph()
        self.port_of = {}          # (u, v) -> out port on u
        self.bytes_prev, self.util = {}, {}
        self.group_id = 1
        self.policy = self._load_policy(os.environ.get("GTN_CKPT"))
        hub.spawn(self._poll)

    # ------------------------------------------------------------ policy
    def _load_policy(self, ckpt):
        if not ckpt:
            self.logger.warning("GTN_CKPT not set: falling back to least-loaded splitting")
            return None
        import torch
        from mgtn_sdn.experiment import build_method
        ck = torch.load(ckpt, weights_only=False)
        pol = build_method(ck["method"], ck["config"], ck["seed"])
        self._ck = ck
        return pol

    def decide(self, paths, src, dst, demand=10.0):
        """Return split ratios over candidate paths. With a checkpoint the
        policy is queried through a live SDNSimulator mirror of the network."""
        k = len(paths)
        if self.policy is None or k == 0:
            resid = [min(1 - self.util.get((u, v), 0.0) for u, v in zip(p[:-1], p[1:])) for p in paths]
            w = np.exp(np.array(resid) * 5)
            return w / w.sum()
        from mgtn_sdn.simulator import SDNSimulator
        from mgtn_sdn.topology import Topology
        from mgtn_sdn.traffic import Request
        idx = {n: i for i, n in enumerate(sorted(self.g.nodes))}
        g = nx.relabel_nodes(self.g, idx)
        cap = {(idx[u], idx[v]): LINK_MBPS for u, v in self.port_of}
        dly = {e: 1.0 for e in cap}
        sim = SDNSimulator(Topology(g, cap, dly), [Request(0, idx[src], idx[dst], demand, 0.0, 1.0)], loss_break=None)
        for (u, v), ut in self.util.items():
            if (idx[u], idx[v]) in sim.lidx:
                sim.load[sim.lidx[(idx[u], idx[v])]] = ut * LINK_MBPS
        self.policy.begin_topology(sim)
        self.policy.load_state_dict(self._ck["state"])
        return self.policy.act(sim, sim.current_request(), False)[:k]

    # ------------------------------------------------------------ topology
    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def features(self, ev):
        dp = ev.msg.datapath
        self.dps[dp.id] = dp
        p, o = dp.ofproto_parser, dp.ofproto
        self._flow(dp, 0, p.OFPMatch(), [p.OFPActionOutput(o.OFPP_CONTROLLER, o.OFPCML_NO_BUFFER)])

    @set_ev_cls([topo_event.EventLinkAdd, topo_event.EventLinkDelete, topo_event.EventSwitchEnter])
    def topo_changed(self, ev):
        self.g.clear(); self.port_of.clear()
        for s in topo_api.get_switch(self, None):
            self.g.add_node(s.dp.id)
        for l in topo_api.get_link(self, None):
            self.g.add_edge(l.src.dpid, l.dst.dpid)
            self.port_of[(l.src.dpid, l.dst.dpid)] = l.src.port_no

    # ------------------------------------------------------------ telemetry
    def _poll(self):
        while True:
            for dp in self.dps.values():
                dp.send_msg(dp.ofproto_parser.OFPPortStatsRequest(dp, 0, dp.ofproto.OFPP_ANY))
            hub.sleep(POLL_S)

    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def port_stats(self, ev):
        dpid = ev.msg.datapath.id
        for st in ev.msg.body:
            key = (dpid, st.port_no)
            prev = self.bytes_prev.get(key, st.tx_bytes)
            self.bytes_prev[key] = st.tx_bytes
            mbps = (st.tx_bytes - prev) * 8 / POLL_S / 1e6
            for (u, v), port in self.port_of.items():
                if u == dpid and port == st.port_no:
                    self.util[(u, v)] = min(mbps / LINK_MBPS, 1.0)

    # ------------------------------------------------------------ routing
    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in(self, ev):
        msg, dp = ev.msg, ev.msg.datapath
        pkt = packet.Packet(msg.data)
        ip = pkt.get_protocol(ipv4.ipv4)
        if ip is None or pkt.get_protocol(ethernet.ethernet) is None:
            return
        src_sw, dst_sw = dp.id, self._host_switch(ip.dst)
        if dst_sw is None or src_sw == dst_sw:
            return
        from itertools import islice
        paths = list(islice(nx.shortest_simple_paths(self.g, src_sw, dst_sw), 4))   # Yen, K = 4
        split = self.decide(paths, src_sw, dst_sw)
        from mgtn_sdn.agent import bucket_weights
        weights = bucket_weights(np.asarray(split) / np.sum(split))
        p, o = dp.ofproto_parser, dp.ofproto
        buckets = [p.OFPBucket(weight=int(w), watch_port=o.OFPP_ANY, watch_group=o.OFPG_ANY,
                               actions=[p.OFPActionOutput(self.port_of[(path[0], path[1])])])
                   for path, w in zip(paths, weights) if w > 0]
        gid = self.group_id; self.group_id += 1
        dp.send_msg(p.OFPGroupMod(dp, o.OFPGC_ADD, o.OFPGT_SELECT, gid, buckets))
        match = p.OFPMatch(eth_type=0x0800, ipv4_src=ip.src, ipv4_dst=ip.dst)
        self._flow(dp, 10, match, [p.OFPActionGroup(gid)], idle=30)
        for path in paths:                                 # downstream hops
            for u, v in zip(path[1:-1], path[2:]):
                d = self.dps.get(u)
                if d:
                    self._flow(d, 10, d.ofproto_parser.OFPMatch(eth_type=0x0800, ipv4_src=ip.src, ipv4_dst=ip.dst),
                               [d.ofproto_parser.OFPActionOutput(self.port_of[(u, v)])], idle=30)

    def _host_switch(self, ip_addr):
        for h in topo_api.get_all_host(self):
            if ip_addr in h.ipv4:
                return h.port.dpid
        return None

    @staticmethod
    def _flow(dp, prio, match, actions, idle=0):
        p, o = dp.ofproto_parser, dp.ofproto
        inst = [p.OFPInstructionActions(o.OFPIT_APPLY_ACTIONS, actions)]
        dp.send_msg(p.OFPFlowMod(datapath=dp, priority=prio, match=match, instructions=inst, idle_timeout=idle))
