"""Seeded hyper-parameter search with a fixed trial budget.

Every re-implemented baseline is tuned *independently* inside its own
algorithm-specific parameter space (configs/baselines.yaml) with the same
number of validation trials (budget = 50 in the paper protocol). A trial
trains on the validation topology and is scored by the cumulative reward on
a held-back validation traffic trace (seed 1000*s + 998) — never on the test
trace. Search is seeded random sampling (uniform / log-uniform / choice).
"""
from __future__ import annotations

import math
from typing import Any, Callable, Dict, List, Tuple

import numpy as np


def sample_space(space: Dict[str, Dict[str, Any]], rng: np.random.Generator) -> Dict[str, Any]:
    out = {}
    for k, spec in space.items():
        t = spec["type"]
        if t == "uniform":
            out[k] = float(rng.uniform(spec["low"], spec["high"]))
        elif t == "loguniform":
            out[k] = float(math.exp(rng.uniform(math.log(spec["low"]), math.log(spec["high"]))))
        elif t == "int":
            out[k] = int(rng.integers(spec["low"], spec["high"] + 1))
        elif t == "choice":
            out[k] = spec["values"][int(rng.integers(len(spec["values"])))]
        else:
            raise ValueError(t)
    return out


def random_search(space: Dict[str, Dict[str, Any]], objective: Callable[[Dict[str, Any]], float],
                  budget: int, seed: int, defaults: Dict[str, Any] | None = None
                  ) -> Tuple[Dict[str, Any], float, List[Dict[str, Any]]]:
    """Trial 0 evaluates the published/default parameters, trials 1..budget-1
    are random samples. Returns (best params, best score, trial log)."""
    rng = np.random.default_rng(seed)
    log, best, best_p = [], -np.inf, None
    for t in range(budget):
        p = dict(defaults or {}) if t == 0 and defaults else sample_space(space, rng)
        score = objective(p)
        log.append({"trial": t, "score": score, **p})
        if score > best:
            best, best_p = score, p
    return best_p, best, log
