"""Experiment runner shared by all scripts: builds any method by name,
trains it on one (size, seed) cell and evaluates it, returning one run-level
row. Run-level rows are appended to CSV so every table can be regenerated
and every statistical test re-run from raw per-run values."""
from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd

from .agent import GraphRoutingAgent
from .baselines import REGISTRY
from .topology import Topology, barabasi_albert_nsfnet
from .trainer import evaluate_policy, train_policy
from .utils import deep_update, set_seed

DISPLAY = {"proposed": "Proposed Multiscale GTN-SDN", "mixhop": "MixHop", "gin": "GIN", "cgc": "CGC",
           "mpnn": "MPNN", "gcn": "GCN", "cahpo": "CAHPO [19]", "d2dqn": "D2DQN [20]", "hgpo": "HGPO [21]",
           "dsenn": "DSENN [22]", "derfdrl": "DERFDRL [23]"}


def build_method(method: str, cfg: dict, seed: int, params: Optional[Dict[str, Any]] = None,
                 encoder: Optional[str] = None, encoder_kw: Optional[dict] = None, head: Optional[str] = None):
    dmax = cfg["simulation"]["traffic_kw"]["demand_range"][1]
    if method in REGISTRY:
        return REGISTRY[method](seed=seed, demand_max=dmax, **(params or {}))
    if method == "proposed" or encoder is not None:
        kw = deep_update(cfg["model"]["encoder_kw"], encoder_kw or {}) if (encoder or "multiscale_gtn") == "multiscale_gtn" else (encoder_kw or {})
        return GraphRoutingAgent(method, encoder or cfg["model"]["encoder"], kw, head or cfg["model"]["head"],
                                 cfg["rl"], demand_max=dmax, seed=seed)
    # graph baselines share the proposed DDPG head (unified setting)
    return GraphRoutingAgent(method, method, {"dropout": cfg["model"]["encoder_kw"]["dropout"]}, "ddpg",
                             cfg["rl"], demand_max=dmax, seed=seed)


def make_topology(cfg: dict, n: int, seed: int) -> Topology:
    t = cfg["topology"]
    return barabasi_albert_nsfnet(n, m=t["ba_m"], link_capacity=t["link_capacity_mbps"], seed=seed)


def run_cell(method: str, cfg: dict, n: int, seed: int, label: Optional[str] = None,
             params: Optional[dict] = None, log=None, extra: Optional[dict] = None,
             return_policy: bool = False, **build_kw):
    set_seed(seed)
    topo = make_topology(cfg, n, seed)
    pol = build_method(method, cfg, seed, params, **build_kw)
    t0 = time.time()
    hist = train_policy(pol, topo, cfg, seed, log=log)
    train_s = time.time() - t0
    res = evaluate_policy(pol, topo, cfg, seed)
    row = {"model": label or DISPLAY.get(method, method), "method": method, "nodes": n, "seed": seed,
           "edges": topo.meta["edges"], "diameter": topo.meta["diameter"],
           "episodes_trained": len(hist), "train_s": round(train_s, 2), "params": pol.n_parameters(),
           **{k: v for k, v in res.items() if k != "reward"}, "eval_reward": res["reward"]}
    if extra:
        row.update(extra)
    if return_policy:
        return row, pol, topo
    return row


def append_rows(rows, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows if isinstance(rows, list) else [rows])
    df.to_csv(path, mode="a", header=not path.exists(), index=False)


def done_keys(path: str | Path, cols=("model", "nodes", "seed")) -> set:
    """Resume support: (model, nodes, seed) cells already in the CSV."""
    path = Path(path)
    if not path.exists():
        return set()
    df = pd.read_csv(path)
    return set(map(tuple, df[list(cols)].astype(str).values.tolist()))
