"""Execution-time and per-step energy measurement.

Measurement boundary (one routing decision)
    start  a traffic-state observation (request + telemetry) arrives at the
           controller
    ...    state preprocessing (features, live adjacency), encoder inference,
           DDPG action selection, candidate-path evaluation, generation of
           the forwarding decision (OpenFlow select-group bucket weights)
    stop   bucket weights are ready
    excluded: packet transmission, switch forwarding, rule-installation RTT
Protocol
    20 warm-up decisions (discarded) + 1000 measured decisions per run,
    5 runs (seeds); clock = time.perf_counter_ns (monotonic). Reported as
    mean +/- SD.
Energy
    E_step = (P_active - P_idle) * t_step
    P is read from Intel RAPL (/sys/class/powercap/intel-rapl:0/energy_uj)
    when readable ("rapl" method). Otherwise the fallback "tdp-utilisation"
    estimator is used: P_active - P_idle ~= TDP * (process CPU-time / wall
    time) / n_logical_cores. The method used is always written next to the
    number so the result can be interpreted. Controller-side computation
    only: link transmission, switch and end-host energy are excluded.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Callable, Dict, Optional

import numpy as np

RAPL = Path("/sys/class/powercap/intel-rapl:0/energy_uj")


def _rapl_uj() -> Optional[int]:
    try:
        return int(RAPL.read_text().strip())
    except Exception:
        return None


def measure(decide: Callable[[], None], warmup: int = 20, measured: int = 1000) -> Dict[str, float]:
    for _ in range(warmup):
        decide()
    ts = np.empty(measured)
    e0 = _rapl_uj()
    c0, w0 = time.process_time(), time.perf_counter()
    for i in range(measured):
        t0 = time.perf_counter_ns()
        decide()
        ts[i] = (time.perf_counter_ns() - t0) / 1e6
    c1, w1 = time.process_time(), time.perf_counter()
    e1 = _rapl_uj()
    return {"exec_ms_mean": float(ts.mean()), "exec_ms_std": float(ts.std(ddof=1)),
            "exec_ms_p95": float(np.percentile(ts, 95)), "wall_s": w1 - w0, "cpu_s": c1 - c0,
            "rapl_j": (e1 - e0) / 1e6 if e0 is not None and e1 is not None and e1 >= e0 else None}


def idle_power(seconds: float = 5.0) -> Optional[float]:
    e0 = _rapl_uj()
    if e0 is None:
        return None
    time.sleep(seconds)
    e1 = _rapl_uj()
    return (e1 - e0) / 1e6 / seconds if e1 is not None and e1 >= e0 else None


def energy_per_step(m: Dict[str, float], measured: int, tdp_watts: float, p_idle: Optional[float]) -> Dict[str, float]:
    t_step = m["exec_ms_mean"] / 1e3
    if m.get("rapl_j") is not None and p_idle is not None:
        p_active = m["rapl_j"] / m["wall_s"]
        return {"energy_j_per_step": max(p_active - p_idle, 0.0) * t_step, "p_active_w": p_active,
                "p_idle_w": p_idle, "energy_method": "rapl"}
    util = m["cpu_s"] / max(m["wall_s"], 1e-9) / (os.cpu_count() or 1)
    dp = tdp_watts * min(util, 1.0)
    return {"energy_j_per_step": dp * t_step, "p_active_minus_idle_w": dp,
            "energy_method": "tdp-utilisation (estimate; RAPL not readable)"}
