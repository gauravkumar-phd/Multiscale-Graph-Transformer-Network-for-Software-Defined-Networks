"""Graph Transformer Network branch (Yun et al., 2019) used as a
meta-path adjacency optimiser, Eqs. (2)-(5).

For every channel c and GTN layer l a 1x1 convolution softly selects a
candidate relation  Q_l^c = sum_t softmax(W_l^c)_t A_t   (Eqs. 2-3) and the
branch composes the meta-path adjacency  A_P^c = D^-1 Q_1^c Q_2^c ... Q_{L+1}^c
(Eqs. 4-5). Candidates of a branch are [pool(s), I]; the identity lets a
branch learn shorter meta-paths. For the 1-hop / 2-hop branches this gives
W in R^{1x1x2}; for the multi-hop branch the candidates are the hop-disjoint
pools k = 3..K_max plus I, so the softmax weights play the role of w_k.

Implementation note: A_P is never materialised. Because the per-layer row
normalisations telescope,  A_P X = diag(1 / (Q_1...Q_{L+1} 1)) Q_1...Q_{L+1} X,
so the sparse factors are applied right-to-left to [X | 1]. All C channels
are processed at once with a block-diagonal sparse operator, so a branch
costs L+1 sparse products per propagation regardless of C. This is exact
and keeps memory O(C(|E| + N d)) instead of O(C N^2).
"""
from __future__ import annotations

from typing import List, Optional, Tuple

import torch
import torch.nn as nn


class GTNBranch(nn.Module):
    def __init__(self, n_candidates: int = 2, n_layers: int = 3, channels: int = 4):
        super().__init__()
        self.n_layers = n_layers
        self.channels = channels
        self.n_candidates = n_candidates
        # (layers + 1) selections because the first GTN layer selects two (Eqs. 2-3)
        self.W = nn.Parameter(torch.randn(n_layers + 1, channels, n_candidates) * 0.01)

    def selection_weights(self) -> torch.Tensor:
        return torch.softmax(self.W, dim=-1)                  # alpha_t^(l), Eq. (5)

    def reset_cache(self) -> None:
        """Called when the topology changes (index pattern must be rebuilt)."""
        self._struct = None

    def _structure(self, cands: List[Optional[torch.Tensor]], n: int):
        """Block-diagonal index pattern for all channels, cached per topology:
        only the values (alpha-weighted candidate weights) change per call."""
        key = (n, tuple(-1 if A is None else A._nnz() for A in cands))
        st = getattr(self, "_struct", None)
        if st is not None and st[0] == key:
            return st[1], st[2], st[3]
        C = self.channels
        ar = torch.arange(n)
        idx_list, ch_list, t_list = [], [], []
        for t, A in enumerate(cands):
            idx = torch.stack([ar, ar]) if A is None else A.indices()
            nnz = idx.shape[1]
            if nnz == 0:
                continue
            off = (torch.arange(C) * n).repeat_interleave(nnz)
            idx_list.append(idx.repeat(1, C) + off)
            ch_list.append(torch.arange(C).repeat_interleave(nnz))
            t_list.append(torch.full((C * nnz,), t, dtype=torch.long))
        idx, ch, tt = torch.cat(idx_list, 1), torch.cat(ch_list), torch.cat(t_list)
        self._struct = (key, idx, ch, tt)
        return idx, ch, tt

    @staticmethod
    def _base_values(cands: List[Optional[torch.Tensor]], n: int, C: int) -> torch.Tensor:
        vals = []
        for A in cands:
            v = torch.ones(n) if A is None else A.values()
            if v.shape[0]:
                vals.append(v.repeat(C))
        return torch.cat(vals)

    def propagate(self, cands: List[Optional[torch.Tensor]], H: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """H: (C, N, d). Returns (A_P^c H for every c as (C, N, d),
        non-empty-row indicator (C, N, 1))."""
        C, n, d = H.shape
        alpha = self.selection_weights()
        idx, ch, tt = self._structure(cands, n)
        base = self._base_values(cands, n, C)
        Y = torch.cat([H, torch.ones(C, n, 1, dtype=H.dtype)], -1).reshape(C * n, d + 1)
        for l in reversed(range(self.n_layers + 1)):
            Q = torch.sparse_coo_tensor(idx, alpha[l][ch, tt] * base, (C * n, C * n))
            Y = torch.sparse.mm(Q, Y)
        Y = Y.reshape(C, n, d + 1)
        r = Y[..., -1:]
        nz = (r > 1e-12).to(H.dtype)
        return Y[..., :-1] / r.clamp(min=1e-12) * nz, nz

    def metapath_matrix(self, cands: List[Optional[torch.Tensor]], n: int, c: int = 0) -> torch.Tensor:
        """Dense A_P^c for inspection / unit tests on small graphs."""
        H = torch.eye(n).unsqueeze(0).repeat(self.channels, 1, 1)
        out, _ = self.propagate(cands, H)
        return out[c]
