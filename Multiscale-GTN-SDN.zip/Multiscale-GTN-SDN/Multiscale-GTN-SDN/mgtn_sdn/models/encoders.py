"""Graph encoders.

MultiscaleGTNEncoder   proposed HHSAD -> 3 parallel GTN branches -> sum
                       aggregation (Eq. 6) -> channel-wise GCN (Eq. 7).
                       Every ablation row of Table 3 is a flag combination.
GCNEncoder, MixHopEncoder, GINEncoder, ChebEncoder (CGC), MPNNEncoder
                       graph baselines of Table 2; all share the same input
                       projection, live adjacency, output size and DDPG head.
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import scipy.sparse as sp
import torch
import torch.nn as nn

from ..hhsad import hhsad_decompose
from .gcn import ChannelGCN
from .gtn import GTNBranch

N_RAW = 8


# ----------------------------------------------------------------- helpers
def sparse_rownorm(A: torch.Tensor) -> torch.Tensor:
    A = A.coalesce()
    idx, val = A.indices(), A.values()
    rs = torch.zeros(A.shape[0]).index_add_(0, idx[0], val)
    return torch.sparse_coo_tensor(idx, val / rs[idx[0]].clamp(min=1e-12), A.shape).coalesce()


def sparse_symnorm(A: torch.Tensor, add_self: bool = False) -> torch.Tensor:
    A = A.coalesce()
    n = A.shape[0]
    idx, val = A.indices(), A.values()
    if add_self:
        ar = torch.arange(n)
        idx = torch.cat([idx, torch.stack([ar, ar])], 1)
        val = torch.cat([val, torch.ones(n)])
    deg = torch.zeros(n).index_add_(0, idx[0], val)
    dinv = deg.clamp(min=1e-12).rsqrt()
    return torch.sparse_coo_tensor(idx, val * dinv[idx[0]] * dinv[idx[1]], (n, n)).coalesce()


def sparse_add_identity(A: torch.Tensor) -> torch.Tensor:
    n = A.shape[0]
    ar = torch.arange(n)
    I = torch.sparse_coo_tensor(torch.stack([ar, ar]), torch.ones(n), (n, n))
    return (A + I).coalesce()


class BaseEncoder(nn.Module):
    out_dim: int = 64

    def prepare(self, struct_adj: sp.spmatrix) -> None:
        """Called once per topology (HHSAD pools are structural)."""

    def forward(self, X: torch.Tensor, graph: Dict[str, torch.Tensor]) -> torch.Tensor:  # pragma: no cover
        raise NotImplementedError


# ----------------------------------------------------------- proposed
class MultiscaleGTNEncoder(BaseEncoder):
    def __init__(self, branches=("1hop", "2hop", "multi"), use_gtn: bool = True,
                 mask: bool = True, merged: bool = False, channels: int = 4,
                 gtn_layers: int = 3, k_max: int = 5, eps: float = 0.05,
                 gcn_refine: bool = True, d_model: int = 64, dropout: float = 0.3,
                 hhsad_norm: str = "sym"):
        super().__init__()
        self.branches = list(branches)
        self.use_gtn, self.mask, self.merged = use_gtn, mask, merged
        self.C, self.k_max, self.eps = channels, k_max, eps
        self.gcn_refine = gcn_refine
        self.hhsad_norm = hhsad_norm
        self.inp = nn.Linear(N_RAW, d_model)
        self.pools = None
        n_cand = {"1hop": 2, "raw": 2, "2hop": 2, "merged": 2, "multi": max(1, k_max - 2) + 1}
        if use_gtn:
            self.gtn = nn.ModuleList([GTNBranch(n_cand[b], gtn_layers, channels) for b in self.branches])
        if gcn_refine:
            self.gcn = ChannelGCN(d_model, 32, 16, dropout)
        else:
            self.proj = nn.Linear(d_model, 16, bias=False)
            self.drop = nn.Dropout(dropout)
        self.out_dim = 16 * channels

    def prepare(self, struct_adj: sp.spmatrix) -> None:
        self.pools = hhsad_decompose(struct_adj, k_max=self.k_max, eps=self.eps,
                                     mask=self.mask, merged=self.merged or "merged" in self.branches,
                                     norm=self.hhsad_norm)
        if self.use_gtn:
            for g in self.gtn:
                g.reset_cache()

    def _branch_cands(self, b: str, A_live: torch.Tensor) -> List[Optional[torch.Tensor]]:
        if b == "1hop":
            return [sparse_symnorm(A_live)]
        if b == "raw":
            return [sparse_add_identity(A_live)]
        if b == "2hop":
            return [self.pools.two_hop]
        if b == "multi":
            return list(self.pools.multi_hop)
        if b == "merged":
            return [self.pools.merged]
        raise ValueError(b)

    def forward(self, X: torch.Tensor, graph: Dict[str, torch.Tensor]) -> torch.Tensor:
        X0 = torch.relu(self.inp(X))
        cands = [self._branch_cands(b, graph["A_live"]) for b in self.branches]

        if self.use_gtn:
            def propagate(H: torch.Tensor) -> torch.Tensor:        # Eq. (6) + (A_agg + I), D^-1
                acc, deg = H, torch.ones(H.shape[0], H.shape[1], 1)
                for gtn, cd in zip(self.gtn, cands):
                    y, nz = gtn.propagate(cd + [None], H)
                    acc, deg = acc + y, deg + nz
                return acc / deg
        else:  # Multiscale-GCN ablation: fixed row-normalised pools, no meta-path learning
            fixed = []
            for cd in cands:
                P = cd[0]
                for extra in cd[1:]:
                    P = (P + extra).coalesce()
                P = sparse_rownorm(P)
                nz = (torch.zeros(P.shape[0]).index_add_(0, P.indices()[0], P.values()) > 0).float()
                fixed.append((P, nz.view(1, -1, 1)))

            def propagate(H: torch.Tensor) -> torch.Tensor:
                C, n, d = H.shape
                acc, deg = H, torch.ones(C, n, 1)
                flat = H.permute(1, 0, 2).reshape(n, C * d)
                for P, nz in fixed:
                    y = torch.sparse.mm(P, flat).reshape(n, C, d).permute(1, 0, 2)
                    acc, deg = acc + y, deg + nz
                return acc / deg

        if self.gcn_refine:
            return self.gcn(propagate, X0, self.C)
        H = propagate(X0.unsqueeze(0).expand(self.C, -1, -1))
        H = torch.relu(self.proj(self.drop(H)))
        return H.permute(1, 0, 2).reshape(X.shape[0], -1)


# ----------------------------------------------------------- baselines
class GCNEncoder(BaseEncoder):
    def __init__(self, d: int = 64, dropout: float = 0.3):
        super().__init__()
        self.inp = nn.Linear(N_RAW, d)
        self.l1, self.l2 = nn.Linear(d, d), nn.Linear(d, d)
        self.drop = nn.Dropout(dropout)

    def forward(self, X, graph):
        A = sparse_symnorm(graph["A_live"], add_self=True)
        H = torch.relu(self.inp(X))
        H = self.drop(torch.relu(torch.sparse.mm(A, self.l1(H))))
        return torch.relu(torch.sparse.mm(A, self.l2(H)))


class MixHopEncoder(BaseEncoder):
    """MixHop (Abu-El-Haija et al., 2019): powers {0,1,2} mixed per layer."""
    def __init__(self, d: int = 64, dropout: float = 0.3, powers=(0, 1, 2)):
        super().__init__()
        self.powers = powers
        self.inp = nn.Linear(N_RAW, d)
        self.w1 = nn.ModuleList([nn.Linear(d, 32) for _ in powers])
        self.w2 = nn.ModuleList([nn.Linear(32 * len(powers), 32) for _ in powers])
        self.out = nn.Linear(32 * len(powers), d)
        self.drop = nn.Dropout(dropout)

    def _layer(self, A, H, ws):
        outs = []
        for p, w in zip(self.powers, ws):
            Y = w(H)
            for _ in range(p):
                Y = torch.sparse.mm(A, Y)
            outs.append(Y)
        return torch.relu(torch.cat(outs, 1))

    def forward(self, X, graph):
        A = sparse_symnorm(graph["A_live"], add_self=True)
        H = torch.relu(self.inp(X))
        H = self.drop(self._layer(A, H, self.w1))
        H = self._layer(A, H, self.w2)
        return torch.relu(self.out(H))


class GINEncoder(BaseEncoder):
    """GIN (Xu et al., 2019) with learnable epsilon."""
    def __init__(self, d: int = 64, dropout: float = 0.3):
        super().__init__()
        self.inp = nn.Linear(N_RAW, d)
        self.eps = nn.Parameter(torch.zeros(2))
        self.m1 = nn.Sequential(nn.Linear(d, d), nn.ReLU(), nn.Linear(d, d))
        self.m2 = nn.Sequential(nn.Linear(d, d), nn.ReLU(), nn.Linear(d, d))
        self.drop = nn.Dropout(dropout)

    def forward(self, X, graph):
        A = graph["A_live"]
        H = torch.relu(self.inp(X))
        H = self.drop(torch.relu(self.m1((1 + self.eps[0]) * H + torch.sparse.mm(A, H))))
        return torch.relu(self.m2((1 + self.eps[1]) * H + torch.sparse.mm(A, H)))


class ChebEncoder(BaseEncoder):
    """Chebyshev graph convolution (CGC; Defferrard et al., 2016), order 3."""
    def __init__(self, d: int = 64, order: int = 3, dropout: float = 0.3):
        super().__init__()
        self.inp = nn.Linear(N_RAW, d)
        self.order = order
        self.w1 = nn.ModuleList([nn.Linear(d, d, bias=(k == 0)) for k in range(order)])
        self.w2 = nn.ModuleList([nn.Linear(d, d, bias=(k == 0)) for k in range(order)])
        self.drop = nn.Dropout(dropout)

    def _cheb(self, L, H, ws):
        T0, out = H, ws[0](H)
        T1 = torch.sparse.mm(L, H)
        if self.order > 1:
            out = out + ws[1](T1)
        for k in range(2, self.order):
            T2 = 2 * torch.sparse.mm(L, T1) - T0
            out = out + ws[k](T2)
            T0, T1 = T1, T2
        return torch.relu(out)

    def forward(self, X, graph):
        An = sparse_symnorm(graph["A_live"])
        L = torch.sparse_coo_tensor(An.indices(), -An.values(), An.shape)  # L~ = L - I, lambda_max ~ 2
        H = torch.relu(self.inp(X))
        H = self.drop(self._cheb(L, H, self.w1))
        return self._cheb(L, H, self.w2)


class MPNNEncoder(BaseEncoder):
    """MPNN (Gilmer et al., 2017): edge-conditioned messages + GRU update."""
    def __init__(self, d: int = 64, rounds: int = 2, edge_dim: int = 3, dropout: float = 0.3):
        super().__init__()
        self.inp = nn.Linear(N_RAW, d)
        self.msg = nn.Sequential(nn.Linear(d + edge_dim, d), nn.ReLU(), nn.Linear(d, d))
        self.upd = nn.GRUCell(d, d)
        self.rounds = rounds
        self.drop = nn.Dropout(dropout)

    def forward(self, X, graph):
        ei, ea = graph["edge_index"], graph["edge_attr"]
        H = torch.relu(self.inp(X))
        for _ in range(self.rounds):
            m = self.msg(torch.cat([H[ei[1]], ea], 1))
            agg = torch.zeros_like(H).index_add_(0, ei[0], m)
            H = self.drop(self.upd(agg, H))
        return H


def build_encoder(name: str, **kw) -> BaseEncoder:
    name = name.lower()
    if name in ("multiscale_gtn", "proposed", "gtn"):
        return MultiscaleGTNEncoder(**kw)
    table = {"gcn": GCNEncoder, "mixhop": MixHopEncoder, "gin": GINEncoder,
             "cgc": ChebEncoder, "cheb": ChebEncoder, "mpnn": MPNNEncoder}
    return table[name](**{k: v for k, v in kw.items() if k in ("d", "dropout")})
