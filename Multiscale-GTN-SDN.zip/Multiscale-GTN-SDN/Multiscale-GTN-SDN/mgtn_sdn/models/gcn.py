"""Downstream channel-wise GCN refinement, Eq. (7).

Z = ||_{c=1..C} sigma( D_c^-1 (A_agg^c + I) X W )

Two layers 64 -> 32 -> 16 with weights shared across channels, no bias,
LayerNorm after the first layer. Parameter count = 64*32 + 32*16 + 2*32
= 2624, matching Table 1.
"""
from __future__ import annotations

from typing import Callable

import torch
import torch.nn as nn


class ChannelGCN(nn.Module):
    def __init__(self, d_in: int = 64, d_hidden: int = 32, d_out: int = 16, dropout: float = 0.3):
        super().__init__()
        self.W1 = nn.Linear(d_in, d_hidden, bias=False)
        self.W2 = nn.Linear(d_hidden, d_out, bias=False)
        self.norm = nn.LayerNorm(d_hidden)
        self.drop = nn.Dropout(dropout)

    def forward(self, propagate: Callable[[torch.Tensor], torch.Tensor], X: torch.Tensor,
                channels: int) -> torch.Tensor:
        """``propagate(H)`` maps (C, N, d) -> D_c^-1 (A_agg^c + I) H_c for all c."""
        H = X.unsqueeze(0).expand(channels, -1, -1)
        H = torch.relu(self.norm(self.W1(propagate(H))))
        H = self.drop(H)
        H = torch.relu(self.W2(propagate(H)))                 # (C, N, 16)
        return H.permute(1, 0, 2).reshape(X.shape[0], -1)     # concatenation over channels


def count_parameters(m: nn.Module) -> int:
    return sum(p.numel() for p in m.parameters() if p.requires_grad)
