"""Traffic-request generation.

Every request is a flow (src, dst, demand_mbps, arrival_s, holding_s).

poisson   (in-distribution) Poisson arrivals, exponential holding times,
          uniform random source/destination matrix, uniform demands.
          The arrival rate is scaled linearly with the network size so the
          offered load per link stays comparable from 200 to 1000 nodes.
bursty    (distribution shift, never seen in training) Markov-modulated
          Poisson process with ON/OFF states (burst factor 4x),
          Pareto (heavy-tailed) holding times and a gravity-model hotspot
          matrix concentrating 40 % of requests on 5 % of the nodes.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np


@dataclass
class Request:
    rid: int
    src: int
    dst: int
    demand: float     # Mbps
    arrival: float    # s
    holding: float    # s


def _pair(rng, n, weights=None):
    if weights is None:
        s, d = rng.choice(n, size=2, replace=False)
        return int(s), int(d)
    s = int(rng.choice(n, p=weights))
    d = s
    while d == s:
        d = int(rng.choice(n, p=weights))
    return s, d


def poisson_traffic(n_nodes: int, n_requests: int, seed: int,
                    base_rate: float = 25.0, ref_nodes: int = 200,
                    mean_holding: float = 4.0, demand_range=(10.0, 60.0)) -> List[Request]:
    rng = np.random.default_rng(seed)
    lam = base_rate * n_nodes / ref_nodes            # linear load scaling
    t = 0.0
    out = []
    for i in range(n_requests):
        t += rng.exponential(1.0 / lam)
        s, d = _pair(rng, n_nodes)
        out.append(Request(i, s, d, float(rng.uniform(*demand_range)), t,
                           float(rng.exponential(mean_holding))))
    return out


def bursty_traffic(n_nodes: int, n_requests: int, seed: int,
                   base_rate: float = 25.0, ref_nodes: int = 200,
                   mean_holding: float = 4.0, demand_range=(10.0, 60.0),
                   burst_factor: float = 4.0, p_on_off: float = 0.02, p_off_on: float = 0.05,
                   pareto_shape: float = 1.5, hotspot_frac: float = 0.05,
                   hotspot_share: float = 0.4) -> List[Request]:
    rng = np.random.default_rng(seed + 31337)
    lam = base_rate * n_nodes / ref_nodes
    # gravity-style hotspot weights
    k = max(2, int(round(hotspot_frac * n_nodes)))
    hot = rng.choice(n_nodes, size=k, replace=False)
    w = np.full(n_nodes, (1 - hotspot_share) / (n_nodes - k))
    w[hot] = hotspot_share / k
    w /= w.sum()
    # Pareto holding times rescaled to the same mean as the Poisson setting
    xm = mean_holding * (pareto_shape - 1) / pareto_shape
    state_on = False
    t = 0.0
    out = []
    for i in range(n_requests):
        if state_on and rng.random() < p_on_off:
            state_on = False
        elif not state_on and rng.random() < p_off_on:
            state_on = True
        rate = lam * (burst_factor if state_on else 1.0)
        t += rng.exponential(1.0 / rate)
        s, d = _pair(rng, n_nodes, w)
        demand = float(np.clip(rng.lognormal(np.log(np.mean(demand_range)), 0.6),
                               demand_range[0], 2 * demand_range[1]))
        hold = float(xm * (1 + rng.pareto(pareto_shape)))
        out.append(Request(i, s, d, demand, t, hold))
    return out


def make_traffic(kind: str, n_nodes: int, n_requests: int, seed: int, **kw) -> List[Request]:
    if kind == "poisson":
        return poisson_traffic(n_nodes, n_requests, seed, **kw)
    if kind == "bursty":
        return bursty_traffic(n_nodes, n_requests, seed, **kw)
    raise ValueError(kind)
