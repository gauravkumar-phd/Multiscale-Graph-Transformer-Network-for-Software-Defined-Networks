"""Flow-level discrete-event SDN data-plane simulator.

Events
    arrival   a new flow request reaches the controller (routing step)
    departure an admitted flow finishes and releases its bandwidth

Link model
    Every directed link is an M/M/1/K queue (K = switch buffer, 1000 packets,
    1500-byte packets). Given the offered load rho = load / capacity we get
    the closed-form blocking probability (packet loss) and mean sojourn time
    (queueing delay). Propagation delay is added per hop. This is the standard
    analytic data-plane abstraction used by flow-level SDN simulators and keeps
    1000-node experiments tractable on a CPU.

Per-request metrics (after the controller installs the split)
    delay       sum_k r_k * sum_{l in p_k} (prop_l + W_l)             [ms]
    loss        sum_k r_k * (1 - prod_{l in p_k} (1 - P_l))           [%]
    throughput  demand * (1 - loss)                                   [Mbps]
Network-wide snapshot metrics
    link utilisation  mean min(rho_l, 1) over links carrying traffic   [%]
    workload / node   Jain fairness index of per-switch forwarded load  [%]
                      (higher = load spread more evenly over switches)
"""
from __future__ import annotations

import heapq
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from .paths import CandidatePaths, path_links
from .topology import Topology
from .traffic import Request


_PATH_CACHES: Dict[Tuple[int, int], CandidatePaths] = {}


def path_cache(topo: Topology, k: int) -> CandidatePaths:
    key = (id(topo.graph), k)
    if key not in _PATH_CACHES or _PATH_CACHES[key].g is not topo.graph:
        _PATH_CACHES[key] = CandidatePaths(topo.graph, k=k)
    return _PATH_CACHES[key]


def mm1k(rho: np.ndarray, K: int) -> Tuple[np.ndarray, np.ndarray]:
    """Vectorised, numerically stable M/M/1/K blocking prob. and mean number
    in system for utilisation array ``rho``."""
    rho = np.asarray(rho, dtype=np.float64)
    rho = np.where(np.abs(rho - 1.0) < 1e-6, 1.0 + 1e-6, rho)
    P = np.empty_like(rho)
    L = np.empty_like(rho)
    lo = rho < 1.0
    r = rho[lo]
    rK = np.power(r, K)
    rK1 = rK * r
    P[lo] = (1 - r) * rK / (1 - rK1)
    L[lo] = r / (1 - r) - (K + 1) * rK1 / (1 - rK1)
    hi = ~lo
    q = 1.0 / rho[hi]
    qK1 = np.power(q, K + 1)
    P[hi] = (1 - q) / (1 - qK1)
    Lq = q / (1 - q) - (K + 1) * qK1 / (1 - qK1)
    L[hi] = K - Lq
    P = np.where(rho <= 0, 0.0, P)
    L = np.where(rho <= 0, 0.0, L)
    return P, L


class SDNSimulator:
    def __init__(self, topo: Topology, requests: Sequence[Request], k_paths: int = 4,
                 buffer_pkts: int = 1000, pkt_bits: int = 12000,
                 loss_break: Optional[float] = 0.5, cand: Optional[CandidatePaths] = None):
        self.topo = topo
        self.requests = list(requests)
        self.K = buffer_pkts
        self.pkt_bits = pkt_bits
        self.loss_break = loss_break
        # candidate paths depend only on the topology -> share one cache
        self.cand = cand if cand is not None else path_cache(topo, k_paths)
        self.k = k_paths
        self.links: List[Tuple[int, int]] = topo.edges
        self.lidx: Dict[Tuple[int, int], int] = {e: i for i, e in enumerate(self.links)}
        self.cap = np.array([topo.capacity[e] for e in self.links])
        self.prop = np.array([topo.prop_delay[e] for e in self.links])
        self.src_node = np.array([e[0] for e in self.links])
        self.dst_node = np.array([e[1] for e in self.links])
        self.n = topo.n
        self._pl_cache: Dict[Tuple[int, int], List[np.ndarray]] = {}
        self.reset()

    # ------------------------------------------------------------------ state
    def reset(self):
        self.load = np.zeros(len(self.links))
        self.flows_on_link = np.zeros(len(self.links))
        self.active: List[Tuple[float, int]] = []          # (end_time, flow_id)
        self.alloc: Dict[int, List[Tuple[np.ndarray, float]]] = {}
        self.t_idx = 0
        self.now = 0.0
        self.done = False
        self.history: List[Dict[str, float]] = []
        return self.current_request()

    def current_request(self) -> Optional[Request]:
        return None if self.done or self.t_idx >= len(self.requests) else self.requests[self.t_idx]

    def paths(self, src: int, dst: int) -> List[List[int]]:
        return self.cand.get(src, dst)

    def path_link_idx(self, src: int, dst: int) -> List[np.ndarray]:
        key = (src, dst)
        if key not in self._pl_cache:
            self._pl_cache[key] = [np.array([self.lidx[e] for e in path_links(p)], dtype=np.int64)
                                   for p in self.paths(src, dst)]
        return self._pl_cache[key]

    def mask(self, src: int, dst: int) -> np.ndarray:
        return self.cand.mask(src, dst)

    @property
    def rho(self) -> np.ndarray:
        return self.load / self.cap

    def link_state(self, extra_load: Optional[np.ndarray] = None):
        load = self.load if extra_load is None else self.load + extra_load
        rho = load / self.cap
        P, L = mm1k(rho, self.K)
        mu = self.cap * 1e6 / self.pkt_bits                  # packets / s
        lam_eff = np.maximum(rho * mu * (1 - P), 1e-9)
        W = np.where(rho > 0, L / lam_eff * 1e3, 1e3 / mu)   # ms
        return rho, P, W

    # ------------------------------------------------------------ features
    def path_features(self, src: int, dst: int, demand: float) -> np.ndarray:
        """[hops, bottleneck residual, post-placement residual, est. delay,
        est. loss] per candidate, zero-padded to K rows."""
        feats = np.zeros((self.k, 5), dtype=np.float32)
        rho, P, W = self.link_state()
        for i, li in enumerate(self.path_link_idx(src, dst)):
            resid = 1 - np.minimum(rho[li], 1)
            post = (self.cap[li] - self.load[li] - demand) / self.cap[li]
            feats[i] = [len(li) / 10.0, resid.min(), np.clip(post.min(), -1, 1),
                        (self.prop[li] + W[li]).sum() / 100.0, 1 - np.prod(1 - P[li])]
        return feats

    # ------------------------------------------------------------ dynamics
    def _release_until(self, t: float):
        while self.active and self.active[0][0] <= t:
            _, fid = heapq.heappop(self.active)
            for li, rate in self.alloc.pop(fid, []):
                self.load[li] -= rate
                self.flows_on_link[li] -= 1
        np.maximum(self.load, 0, out=self.load)

    def step(self, split: np.ndarray) -> Tuple[Dict[str, float], bool]:
        req = self.current_request()
        assert req is not None, "episode finished"
        self.now = req.arrival
        self._release_until(self.now)
        plinks = self.path_link_idx(req.src, req.dst)
        split = np.asarray(split, dtype=np.float64)[: len(plinks)]
        if len(plinks) == 0 or split.sum() <= 0:
            metrics = {"delay": np.nan, "loss": 100.0, "throughput": 0.0}
        else:
            split = split / split.sum()
            fl = []
            for li, r in zip(plinks, split):
                if r <= 1e-6:
                    continue
                rate = req.demand * r
                np.add.at(self.load, li, rate)
                np.add.at(self.flows_on_link, li, 1)
                fl.append((li, rate))
            self.alloc[req.rid] = fl
            heapq.heappush(self.active, (req.arrival + req.holding, req.rid))
            rho, P, W = self.link_state()
            d = l = 0.0
            for li, r in zip(plinks, split):
                d += r * (self.prop[li] + W[li]).sum()
                l += r * (1 - np.prod(1 - P[li]))
            metrics = {"delay": float(d), "loss": float(100 * l),
                       "throughput": float(req.demand * (1 - l))}
        rho, P, _ = self.link_state()
        used = self.load > 1e-9
        metrics["link_util"] = float(100 * np.minimum(rho[used], 1).mean()) if used.any() else 0.0
        node_load = np.bincount(self.src_node, weights=self.load, minlength=self.n)
        busy = node_load[node_load > 0]
        metrics["workload"] = float(100 * busy.sum() ** 2 / (len(busy) * (busy ** 2).sum())) if len(busy) else 0.0
        metrics["max_link_loss"] = float(P.max()) if len(P) else 0.0
        self.history.append(metrics)
        self.t_idx += 1
        if self.t_idx >= len(self.requests):
            self.done = True
        if self.loss_break is not None and metrics["max_link_loss"] >= self.loss_break:
            self.done = True
        return metrics, self.done

    # ------------------------------------------------------------ summary
    def summary(self) -> Dict[str, float]:
        if not self.history:
            return {}
        h = self.history
        g = lambda k: float(np.nanmean([x[k] for x in h]))  # noqa: E731
        return {"packet_loss": g("loss"), "delay": g("delay"), "throughput": g("throughput"),
                "workload": g("workload"), "link_util": g("link_util"), "steps": len(h)}


def reward_from_metrics(m: Dict[str, float], w=(0.4, 0.4, 0.2), norm=None) -> float:
    """Eq. (8): R = w1(-Delay) + w2(-Loss) + w3(Throughput) with min-max
    normalisation of every term to [0, 1] (bounds in ``norm``)."""
    norm = norm or {"delay": (0.0, 200.0), "loss": (0.0, 100.0), "throughput": (0.0, 120.0)}
    def mm(k, v):
        lo, hi = norm[k]
        return float(np.clip((v - lo) / (hi - lo), 0, 1))
    d = mm("delay", m["delay"]) if np.isfinite(m["delay"]) else 1.0
    return -w[0] * d - w[1] * mm("loss", m["loss"]) + w[2] * mm("throughput", m["throughput"])
