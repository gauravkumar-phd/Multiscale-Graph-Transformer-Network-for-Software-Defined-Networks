"""Multiscale GTN-SDN: Multiscale Graph Transformer Network for dynamic
traffic engineering in Software Defined Networks.

Package layout
--------------
utils        seeding, config loading, logging helpers
topology     NSFNET-inspired Barabasi-Albert topologies + held-out families
traffic      Poisson (in-distribution) and bursty/hotspot (shifted) traffic
paths        Yen's K-shortest loop-free candidate paths (K = 4)
simulator    flow-level discrete-event SDN data-plane simulator (M/M/1/K links)
features     node telemetry features and live adjacency construction
hhsad        Hierarchical Hop-Specific Adjacency Decomposition
models       GTN branches, GCN refinement, graph encoders (proposed + baselines)
rl           DDPG actor-critic routing head, replay buffer
baselines    re-implemented CAHPO, D2DQN, HGPO, DSENN, DERFDRL
agent        encoder + routing head wrapper used by every learning method
trainer      training / evaluation loops and model-selection rule
stats        paired tests, Holm correction, effect sizes, confidence intervals
profiling    execution-time boundary and per-step energy estimation
tuning       seeded random / grid search with a fixed trial budget
"""

import warnings

warnings.filterwarnings("ignore", message="Sparse invariant checks")

__version__ = "1.0.0"
