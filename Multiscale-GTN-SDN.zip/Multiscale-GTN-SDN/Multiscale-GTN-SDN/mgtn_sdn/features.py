"""State representation G_t = (V, E, X_t, A_t) built from live telemetry."""
from __future__ import annotations

import numpy as np
import torch

from .simulator import SDNSimulator

RAW_FEATURES = ["queue_len", "active_flows", "mean_out_util", "max_out_util",
                "degree", "mean_residual_bw", "is_src", "is_dst"]


def node_features(sim: SDNSimulator, src: int, dst: int) -> np.ndarray:
    """Raw per-switch telemetry, min-max normalised column-wise (Sec. 2.1).
    Shape (N, 8). A linear layer inside the encoder maps it to 64-d."""
    n = sim.n
    rho, P, W = sim.link_state()
    from .simulator import mm1k
    _, L = mm1k(rho, sim.K)
    s = sim.src_node
    deg = np.bincount(s, minlength=n).astype(np.float64)
    deg_safe = np.maximum(deg, 1)
    q = np.bincount(s, weights=L / sim.K, minlength=n) / deg_safe
    flows = np.bincount(s, weights=sim.flows_on_link, minlength=n)
    util = np.minimum(rho, 1.0)
    mean_u = np.bincount(s, weights=util, minlength=n) / deg_safe
    max_u = np.zeros(n)
    np.maximum.at(max_u, s, util)
    resid = np.bincount(s, weights=1 - util, minlength=n) / deg_safe
    is_s = np.zeros(n); is_s[src] = 1
    is_d = np.zeros(n); is_d[dst] = 1
    X = np.stack([q, flows, mean_u, max_u, deg, resid, is_s, is_d], axis=1)
    lo, hi = X.min(0), X.max(0)
    X = (X - lo) / np.where(hi - lo > 1e-12, hi - lo, 1.0)
    return X.astype(np.float32)


def live_adjacency(sim: SDNSimulator, floor: float = 0.01) -> torch.Tensor:
    """1-hop adjacency whose entries are normalised residual-bandwidth
    fractions (edge features); A_ij = 0 means no physical link."""
    rho = sim.rho
    vals = np.clip(1 - rho, floor, 1.0).astype(np.float32)
    idx = torch.tensor(np.stack([sim.src_node, sim.dst_node]), dtype=torch.long)
    return torch.sparse_coo_tensor(idx, torch.from_numpy(vals), (sim.n, sim.n)).coalesce()


def structural_adjacency(sim: SDNSimulator) -> torch.Tensor:
    idx = torch.tensor(np.stack([sim.src_node, sim.dst_node]), dtype=torch.long)
    vals = torch.ones(idx.shape[1])
    return torch.sparse_coo_tensor(idx, vals, (sim.n, sim.n)).coalesce()
