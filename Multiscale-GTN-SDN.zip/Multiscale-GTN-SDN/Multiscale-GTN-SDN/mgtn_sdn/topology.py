"""Topology generation.

In-distribution (training / tuning / main tables)
    NSFNET-inspired scale-free graphs grown with the Barabasi-Albert model
    (m = 2) from the 14-node NSFNET-like backbone seed, 200-1000 nodes,
    150 Mbps links.

Held-out families (generalisation test, never used for training or tuning)
    waxman          geometric random graphs (distance-dependent links)
    watts_strogatz  small-world ring lattices with rewiring
    grid            2-D torus / lattice (regular, large diameter)
    file            any GraphML / GML / edge-list topology, e.g. a real
                    Internet Topology Zoo network supplied by the user
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import networkx as nx
import numpy as np


@dataclass
class Topology:
    graph: nx.Graph
    capacity: Dict[Tuple[int, int], float]      # Mbps, directed key (u, v)
    prop_delay: Dict[Tuple[int, int], float]    # ms, directed key (u, v)
    family: str = "ba"
    meta: Dict[str, float] = field(default_factory=dict)

    @property
    def n(self) -> int:
        return self.graph.number_of_nodes()

    @property
    def edges(self) -> List[Tuple[int, int]]:
        """Directed link list (both directions of every physical link)."""
        return list(self.capacity.keys())

    def describe(self) -> Dict[str, float]:
        g = self.graph
        diam = nx.diameter(g) if nx.is_connected(g) else float("nan")
        return {"family": self.family, "nodes": g.number_of_nodes(),
                "edges": g.number_of_edges(), "diameter": diam}


def _nsfnet_like_seed(rng: np.random.Generator) -> nx.Graph:
    """A 14-node, 21-link backbone with NSFNET-like size and mean degree
    (3-regular: 14 nodes, 21 links). Used only as the growth seed."""
    while True:
        g = nx.random_regular_graph(3, 14, seed=int(rng.integers(1 << 30)))
        if nx.is_connected(g):
            return nx.convert_node_labels_to_integers(g)


def _finalise(g: nx.Graph, family: str, link_capacity: float, rng: np.random.Generator,
              delay_range=(1.0, 5.0)) -> Topology:
    g = nx.convert_node_labels_to_integers(g)
    g.remove_edges_from(nx.selfloop_edges(g))
    if not nx.is_connected(g):  # keep largest component
        comp = max(nx.connected_components(g), key=len)
        g = nx.convert_node_labels_to_integers(g.subgraph(comp).copy())
    cap, dly = {}, {}
    for u, v in g.edges():
        d = float(rng.uniform(*delay_range))
        for a, b in ((u, v), (v, u)):
            cap[(a, b)] = float(link_capacity)
            dly[(a, b)] = d
    topo = Topology(g, cap, dly, family=family)
    topo.meta = topo.describe()
    return topo


def barabasi_albert_nsfnet(n: int, m: int = 2, link_capacity: float = 150.0,
                           seed: int = 0) -> Topology:
    """Scale an NSFNET-like seed up to ``n`` nodes by preferential attachment."""
    rng = np.random.default_rng(seed)
    seed_graph = _nsfnet_like_seed(rng)
    g = nx.barabasi_albert_graph(n, m, seed=int(rng.integers(1 << 30)),
                                 initial_graph=seed_graph)
    return _finalise(g, "ba", link_capacity, rng)


def held_out_topology(family: str, n: int, link_capacity: float = 150.0, seed: int = 0,
                      path: Optional[str] = None) -> Topology:
    rng = np.random.default_rng(seed + 7919)
    if family == "waxman":
        # Degree tuned to be comparable with BA(m=2) (mean degree ~4)
        g = None
        for beta in np.linspace(0.05, 0.6, 30):
            g = nx.waxman_graph(n, beta=float(beta), alpha=0.25, seed=int(rng.integers(1 << 30)))
            if nx.is_connected(g) and 2 * g.number_of_edges() / n >= 3.5:
                break
    elif family == "watts_strogatz":
        g = nx.connected_watts_strogatz_graph(n, 4, 0.1, seed=int(rng.integers(1 << 30)))
    elif family == "grid":
        side = int(np.ceil(np.sqrt(n)))
        g = nx.grid_2d_graph(side, side, periodic=True)
    elif family == "file":
        if not path:
            raise ValueError("family='file' needs a topology path (GraphML/GML/edgelist)")
        if path.endswith(".graphml"):
            g = nx.Graph(nx.read_graphml(path))
        elif path.endswith(".gml"):
            g = nx.Graph(nx.read_gml(path, label="id"))
        else:
            g = nx.read_edgelist(path, nodetype=int)
    else:
        raise ValueError(f"unknown topology family {family}")
    return _finalise(g, family, link_capacity, rng)


def fail_links(topo: Topology, fraction: float, seed: int = 0) -> Topology:
    """Randomly disable ``fraction`` of the physical links while keeping the
    graph connected when possible (links whose removal disconnects the graph
    are skipped, which mirrors protected bridge links in practice)."""
    rng = np.random.default_rng(seed + 104729)
    g = topo.graph.copy()
    edges = list(g.edges())
    rng.shuffle(edges)
    target = int(round(fraction * len(edges)))
    removed = 0
    for u, v in edges:
        if removed >= target:
            break
        g.remove_edge(u, v)
        if nx.is_connected(g):
            removed += 1
        else:
            g.add_edge(u, v)
    cap = {k: c for k, c in topo.capacity.items() if g.has_edge(*k)}
    dly = {k: d for k, d in topo.prop_delay.items() if g.has_edge(*k)}
    out = Topology(g, cap, dly, family=topo.family + f"+fail{fraction:.2f}")
    out.meta = out.describe()
    out.meta["failed_links"] = removed
    return out
