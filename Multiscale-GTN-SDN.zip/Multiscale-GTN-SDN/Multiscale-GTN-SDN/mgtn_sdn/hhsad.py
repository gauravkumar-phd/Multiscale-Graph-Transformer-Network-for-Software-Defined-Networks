"""Hierarchical Hop-Specific Adjacency Decomposition (HHSAD), Sec. 2.2.

Given the structural adjacency A (self-loops removed) and its symmetric
normalisation  A_hat = D^-1/2 A D^-1/2  we build hop-disjoint pools

    P^(k)_ij = (A_hat^k  (.)  M^(k))_ij   if  > eps   else 0          Eq. (1)

where M^(k)_ij = 1 only when the shortest-path distance d(i, j) == k
(hop-disjoint masking). Pools:

    1-hop      {A}  (live residual-bandwidth weights, rebuilt every step)
    2-hop      P^(2)
    multi-hop  sum_{k=3..K_max} w_k P^(k)   (w_k learnable in the encoder)

Switches supported for the targeted ablation (configs/ablation.yaml):
    mask=False        -> A_hat^k without M^(k) (overlapping hop footprints)
    merged=True       -> single pool sum_{k=1..K_max} M^(k) (.) A_hat^k
                         (hop-disjoint masking *without* decomposition)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np
import scipy.sparse as sp
import torch
from scipy.sparse.csgraph import shortest_path


def _to_torch_sparse(m: np.ndarray | sp.spmatrix) -> torch.Tensor:
    m = sp.coo_matrix(m)
    idx = torch.tensor(np.vstack([m.row, m.col]), dtype=torch.long)
    return torch.sparse_coo_tensor(idx, torch.tensor(m.data, dtype=torch.float32), m.shape).coalesce()


@dataclass
class HHSADPools:
    two_hop: torch.Tensor
    multi_hop: List[torch.Tensor]          # one pool per k = 3..K_max
    merged: torch.Tensor | None = None
    stats: Dict[str, float] = field(default_factory=dict)


def hhsad_decompose(adj: sp.spmatrix | np.ndarray, k_max: int = 5, eps: float = 0.05,
                    mask: bool = True, merged: bool = False, norm: str = "sym") -> HHSADPools:
    """norm='sym' (paper, default): A_hat = D^-1/2 A D^-1/2.
    norm='rw': A_hat = D^-1 A, so (A_hat^k)_ij is the k-step random-walk
    probability; optional variant that keeps more long-range entries above
    eps on large scale-free graphs (see README, 'HHSAD pool density')."""
    A = sp.csr_matrix(adj, dtype=np.float64)
    A.setdiag(0)
    A.eliminate_zeros()
    A.data[:] = 1.0
    n = A.shape[0]
    deg = np.asarray(A.sum(1)).ravel()
    if norm == "sym":
        dinv = sp.diags(1.0 / np.sqrt(np.maximum(deg, 1)))
        Ahat = (dinv @ A @ dinv).toarray()
    elif norm == "rw":
        Ahat = (sp.diags(1.0 / np.maximum(deg, 1)) @ A).toarray()
    else:
        raise ValueError(norm)
    dist = shortest_path(A, method="D", unweighted=True)

    stats: Dict[str, float] = {"nodes": n, "norm": norm, "eps": eps}
    pools: Dict[int, np.ndarray] = {}
    Ak = Ahat.copy()
    for k in range(2, k_max + 1):
        Ak = Ak @ Ahat
        P = Ak * (dist == k) if mask else Ak.copy()
        np.fill_diagonal(P, 0.0)
        P[P <= eps] = 0.0                                       # Eq. (1) sparsification
        pools[k] = P
        stats[f"nnz_hop{k}"] = int((P > 0).sum())
        stats[f"pairs_at_dist{k}"] = int((dist == k).sum())
    two = _to_torch_sparse(pools[2])
    multi = [_to_torch_sparse(pools[k]) for k in range(3, k_max + 1)]
    mg = None
    if merged:
        M = Ahat * (dist == 1)
        for k in range(2, k_max + 1):
            M = M + pools[k]
        mg = _to_torch_sparse(M)
    return HHSADPools(two, multi, mg, stats)
