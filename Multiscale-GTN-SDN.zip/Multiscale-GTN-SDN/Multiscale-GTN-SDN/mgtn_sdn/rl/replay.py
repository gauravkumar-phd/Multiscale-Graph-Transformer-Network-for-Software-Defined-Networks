from __future__ import annotations

import numpy as np
import torch


class ReplayBuffer:
    """Uniform replay of (S, mask, a, R, S', mask', done) transition tuples."""

    def __init__(self, capacity: int, s_dim: int, a_dim: int, seed: int = 0):
        self.cap = capacity
        self.s = np.zeros((capacity, s_dim), np.float32)
        self.m = np.zeros((capacity, a_dim), np.float32)
        self.a = np.zeros((capacity, a_dim), np.float32)
        self.r = np.zeros((capacity, 1), np.float32)
        self.s2 = np.zeros((capacity, s_dim), np.float32)
        self.m2 = np.zeros((capacity, a_dim), np.float32)
        self.d = np.zeros((capacity, 1), np.float32)
        self.ptr = self.size = 0
        self.rng = np.random.default_rng(seed)

    def add(self, s, m, a, r, s2, m2, d):
        i = self.ptr
        self.m[i] = m
        self.s[i], self.a[i], self.r[i], self.s2[i], self.m2[i], self.d[i] = s, a, r, s2, m2, d
        self.ptr = (self.ptr + 1) % self.cap
        self.size = min(self.size + 1, self.cap)

    def sample(self, batch: int):
        idx = self.rng.integers(0, self.size, size=batch)
        t = lambda x: torch.from_numpy(x[idx])  # noqa: E731
        return t(self.s), t(self.m), t(self.a), t(self.r), t(self.s2), t(self.m2), t(self.d)

    def __len__(self):
        return self.size
