"""DDPG routing head (Sec. 2.5, Eqs. 8-11).

Actor  mu(S)    : MLP(256, 128) -> K logits -> masked softmax = split ratios
Critic Q(S, a)  : MLP(256, 128) -> scalar
Critic loss     : mean-squared Bellman error, Eq. (9)
Actor gradient  : grad J ~ 1/B sum grad_a Q(S, a)|a=mu(S) grad mu(S), Eq. (10)
Targets         : soft update  theta' <- tau theta + (1 - tau) theta', Eq. (11)
Exploration     : Gaussian action noise sigma0 = 0.2, truncated to [-0.5, 0.5],
                  decayed x0.995 per episode; ratios are re-projected onto the
                  simplex restricted to valid (unmasked) candidate paths.
"""
from __future__ import annotations

import copy

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def mlp(d_in: int, d_out: int, hidden=(256, 128)) -> nn.Sequential:
    layers, d = [], d_in
    for h in hidden:
        layers += [nn.Linear(d, h), nn.ReLU()]
        d = h
    layers.append(nn.Linear(d, d_out))
    return nn.Sequential(*layers)


def masked_softmax(logits: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    logits = logits.masked_fill(mask <= 0, -1e9)
    return torch.softmax(logits, dim=-1) * (mask > 0).float()


class Actor(nn.Module):
    """Deterministic policy mu(S) -> split ratios.

    If ``path_dim`` is given the state layout is [K blocks of path_dim | global]
    and the MLP (256, 128) is shared across the K candidate slots, i.e.
    logit_k = MLP([path_k, global]). This makes the actor permutation-
    equivariant over candidates (no positional bias toward slot 1) while the
    lookup mask removes unavailable routes. Otherwise a flat MLP is used.
    """
    def __init__(self, s_dim: int, k: int, hidden=(256, 128), path_dim: int | None = None):
        super().__init__()
        self.k, self.path_dim = k, path_dim
        self.logit_bound = 3.0
        if path_dim:
            self.g_dim = s_dim - k * path_dim
            self.net = mlp(path_dim + self.g_dim, 1, hidden)
        else:
            self.net = mlp(s_dim, k, hidden)

    def forward(self, s, mask):
        if self.path_dim:
            B = s.shape[0]
            per = s[:, : self.k * self.path_dim].reshape(B, self.k, self.path_dim)
            g = s[:, self.k * self.path_dim:].unsqueeze(1).expand(B, self.k, self.g_dim)
            logits = self.net(torch.cat([per, g], -1)).squeeze(-1)
        else:
            logits = self.net(s)
        # bounded logits keep the split ratios in the interior of the simplex
        # (max ratio between two paths e^(2L)) so the deterministic policy
        # gradient does not saturate the softmax
        valid = (mask > 0).float()
        centre = (logits * valid).sum(-1, keepdim=True) / valid.sum(-1, keepdim=True).clamp(min=1)
        logits = self.logit_bound * torch.tanh((logits - centre) / self.logit_bound)
        return masked_softmax(logits, mask)


class Critic(nn.Module):
    def __init__(self, s_dim: int, k: int, hidden=(256, 128)):
        super().__init__()
        self.net = mlp(s_dim + k, 1, hidden)

    def forward(self, s, a):
        return self.net(torch.cat([s, a], -1))


class DDPGHead:
    def __init__(self, s_dim: int, k: int, cfg: dict, seed: int = 0, path_dim: int | None = None):
        hidden = tuple(cfg.get("hidden", (256, 128)))
        self.k = k
        self.actor, self.critic = Actor(s_dim, k, hidden, path_dim), Critic(s_dim, k, hidden)
        self.actor_t, self.critic_t = copy.deepcopy(self.actor), copy.deepcopy(self.critic)
        lr, wd = cfg.get("lr", 1e-3), cfg.get("weight_decay", 1e-4)
        self.opt_a = torch.optim.AdamW(self.actor.parameters(), lr=lr, weight_decay=wd)
        self.opt_c = torch.optim.AdamW(self.critic.parameters(), lr=lr, weight_decay=wd)
        self.gamma, self.tau = cfg.get("gamma", 0.95), cfg.get("tau", 0.005)
        self.sigma = cfg.get("sigma0", 0.2)
        self.sigma_decay = cfg.get("sigma_decay", 0.995)
        self.clip = cfg.get("noise_clip", 0.5)
        self.rng = np.random.default_rng(seed)

    def explore(self, a: np.ndarray, mask: np.ndarray) -> np.ndarray:
        noise = np.clip(self.rng.normal(0, self.sigma, size=a.shape), -self.clip, self.clip)
        a = np.clip(a + noise, 0, None) * mask
        s = a.sum()
        return a / s if s > 0 else mask / mask.sum()

    def end_episode(self):
        self.sigma *= self.sigma_decay

    def update(self, batch):
        s, m, a, r, s2, m2, d = batch
        with torch.no_grad():
            y = r + self.gamma * (1 - d) * self.critic_t(s2, self.actor_t(s2, m2))
        lc = F.mse_loss(self.critic(s, a), y)                         # Eq. (9)
        self.opt_c.zero_grad(); lc.backward(); self.opt_c.step()
        la = -self.critic(s, self.actor(s, m)).mean()                 # Eq. (10)
        self.opt_a.zero_grad(); la.backward(); self.opt_a.step()
        for net, tgt in ((self.actor, self.actor_t), (self.critic, self.critic_t)):
            for p, pt in zip(net.parameters(), tgt.parameters()):    # Eq. (11)
                pt.data.mul_(1 - self.tau).add_(self.tau * p.data)
        return float(lc.detach()), float(la.detach())

    def state_dict(self):
        return {k: getattr(self, k).state_dict() for k in ("actor", "critic", "actor_t", "critic_t")}

    def load_state_dict(self, sd):
        for k, v in sd.items():
            getattr(self, k).load_state_dict(v)
