"""Routing policies.

RoutingPolicy         interface shared by every method (proposed, graph
                      baselines, re-implemented baselines, ablations).
GraphRoutingAgent     graph encoder -> routing-state builder -> head, where
                      head is one of
                        ddpg      proposed DDPG actor-critic (Sec. 2.5)
                        myopic    "without RL": supervised one-step regression
                                  of the observed reward, no bootstrapping,
                                  no critic, no exploration
                        shortest  "static shortest path": 100 % on path 1
"""
from __future__ import annotations

import copy
from typing import Dict, Optional

import numpy as np
import scipy.sparse as sp
import torch
import torch.nn as nn

from .features import live_adjacency, node_features
from .models.encoders import build_encoder
from .rl.ddpg import DDPGHead, masked_softmax
from .rl.replay import ReplayBuffer
from .simulator import SDNSimulator
from .traffic import Request


def bucket_weights(split: np.ndarray, total: int = 100) -> np.ndarray:
    """Convert split ratios to integer OpenFlow select-group bucket weights
    (largest-remainder rounding). This is the 'forwarding decision'."""
    raw = split * total
    w = np.floor(raw).astype(int)
    rem = total - w.sum()
    if rem > 0:
        w[np.argsort(-(raw - w))[:rem]] += 1
    return w


class RoutingPolicy:
    name = "policy"
    k = 4

    def begin_topology(self, sim: SDNSimulator) -> None: ...
    def act(self, sim: SDNSimulator, req: Request, train: bool) -> np.ndarray: raise NotImplementedError
    def observe(self, sim: SDNSimulator, reward: float, done: bool, train: bool) -> None: ...
    def end_episode(self) -> None: ...
    def state_dict(self): return {}
    def load_state_dict(self, sd) -> None: ...
    def n_parameters(self) -> int: return 0


class GraphRoutingAgent(RoutingPolicy):
    def __init__(self, name: str, encoder_name: str, encoder_kw: dict, head: str,
                 rl_cfg: dict, k: int = 4, demand_max: float = 60.0, seed: int = 0):
        self.name, self.k, self.head_type = name, k, head
        self.encoder = build_encoder(encoder_name, **encoder_kw)
        d = self.encoder.out_dim
        self.s_dim = k * (d + 5) + 2 * d + 1
        self.dmax = demand_max
        self.cfg = rl_cfg
        self.update_every = rl_cfg.get("update_every", 1)
        self.batch = rl_cfg.get("batch_size", 64)
        self.opt_enc = torch.optim.AdamW(self.encoder.parameters(), lr=rl_cfg.get("lr", 1e-3),
                                        weight_decay=rl_cfg.get("weight_decay", 1e-4))
        if head == "ddpg":
            self.head = DDPGHead(self.s_dim, k, rl_cfg, seed, path_dim=d + 5)
            self.buffer = ReplayBuffer(rl_cfg.get("buffer", 100_000), self.s_dim, k, seed)
        elif head == "myopic":
            self.scorer = nn.Linear(d + 5, 1)
            self.opt_enc = torch.optim.AdamW(list(self.encoder.parameters()) + list(self.scorer.parameters()),
                                            lr=rl_cfg.get("lr", 1e-3), weight_decay=rl_cfg.get("weight_decay", 1e-4))
        self._pending = None
        self._steps = 0

    # ---------------------------------------------------------- state
    def begin_topology(self, sim: SDNSimulator) -> None:
        A = sp.coo_matrix((np.ones(len(sim.links)), (sim.src_node, sim.dst_node)), shape=(sim.n, sim.n))
        self.encoder.prepare(A)
        self._ei = torch.tensor(np.stack([sim.src_node, sim.dst_node]), dtype=torch.long)
        self._prop = torch.tensor(sim.prop / 5.0, dtype=torch.float32)
        self._pending = None

    def _graph(self, sim: SDNSimulator) -> Dict[str, torch.Tensor]:
        rho = torch.tensor(np.minimum(sim.rho, 1.0), dtype=torch.float32)
        return {"A_live": live_adjacency(sim), "edge_index": self._ei,
                "edge_attr": torch.stack([1 - rho, rho, self._prop], 1)}

    def build_state(self, sim: SDNSimulator, req: Request):
        X = torch.from_numpy(node_features(sim, req.src, req.dst))
        Z = self.encoder(X, self._graph(sim))
        pf = torch.from_numpy(sim.path_features(req.src, req.dst, req.demand))
        pooled = []
        paths = sim.paths(req.src, req.dst)
        for i in range(self.k):
            pooled.append(Z[paths[i]].mean(0) if i < len(paths) else torch.zeros(Z.shape[1]))
        P = torch.stack(pooled)                                            # (K, d)
        # layout: K blocks [pooled path embedding | path features], then global part
        s = torch.cat([torch.cat([P, pf], 1).flatten(), Z[req.src], Z[req.dst],
                       torch.tensor([req.demand / self.dmax])])
        return s, P, pf

    # ---------------------------------------------------------- acting
    def act(self, sim, req, train):
        mask = sim.mask(req.src, req.dst)
        if self.head_type == "shortest":
            a = np.zeros(self.k, np.float32); a[0] = 1.0
            return a
        self.encoder.train(train)
        ctx = torch.enable_grad() if train else torch.no_grad()
        with ctx:
            s, P, pf = self.build_state(sim, req)
        mt = torch.from_numpy(mask)
        if self.head_type == "myopic":
            with ctx:
                score = self.scorer(torch.cat([P, pf], 1)).squeeze(1)   # predicted reward per path
            a = masked_softmax(score.detach() / self.cfg.get("myopic_temp", 0.05), mt).numpy()
            if train:
                self._pending = (score, torch.from_numpy(a))
            return a
        with torch.no_grad():
            a = self.head.actor(s.detach().unsqueeze(0), mt.unsqueeze(0))[0].numpy()
        if train:
            a = self.head.explore(a, mask)
            s_np = s.detach().numpy()
            if self._pending is not None and self._pending[0] == "await_next":
                _, ps, pm, pa, pr = self._pending
                self.buffer.add(ps, pm, pa, pr, s_np, mask, 0.0)
            self._cur = (s, s_np, mask, a)
        return a.astype(np.float32)

    # ---------------------------------------------------------- learning
    def observe(self, sim, reward, done, train):
        if not train or self.head_type == "shortest":
            return
        self._steps += 1
        if self.head_type == "myopic":
            score, a = self._pending
            # one-step supervised regression: sum_k a_k * score_k  ->  observed reward
            loss = ((a * score).sum() - reward).pow(2)
            self.opt_enc.zero_grad(); loss.backward(); self.opt_enc.step()
            self._pending = None
            return
        s, s_np, mask, a = self._cur
        if done:
            self.buffer.add(s_np, mask, a, reward, np.zeros_like(s_np), np.zeros_like(mask), 1.0)
            self._pending = None
        else:
            self._pending = ("await_next", s_np, mask, a, reward)
        if len(self.buffer) >= self.batch and self._steps % self.update_every == 0:
            self.head.update(self.buffer.sample(self.batch))
            # end-to-end encoder update: the encoder is part of the actor, so its
            # gradient flows only through the action mu(S); the critic sees a
            # detached state (otherwise the encoder could inflate Q by moving
            # the state itself, which diverges)
            mt = torch.from_numpy(mask).unsqueeze(0)
            q = self.head.critic(s.detach().unsqueeze(0), self.head.actor(s.unsqueeze(0), mt))
            params = [p for p in self.encoder.parameters() if p.requires_grad]
            grads = torch.autograd.grad(-q.mean(), params, allow_unused=True)
            self.opt_enc.zero_grad()
            for p, g in zip(params, grads):
                p.grad = g
            self.opt_enc.step()

    def end_episode(self):
        if self.head_type == "ddpg":
            self.head.end_episode()
        self._pending = None

    # ---------------------------------------------------------- persistence
    def state_dict(self):
        sd = {"encoder": copy.deepcopy(self.encoder.state_dict())}
        if self.head_type == "ddpg":
            sd["head"] = copy.deepcopy(self.head.state_dict())
        if self.head_type == "myopic":
            sd["scorer"] = copy.deepcopy(self.scorer.state_dict())
        return sd

    def load_state_dict(self, sd):
        self.encoder.load_state_dict(sd["encoder"])
        if "head" in sd:
            self.head.load_state_dict(sd["head"])
        if "scorer" in sd:
            self.scorer.load_state_dict(sd["scorer"])

    def n_parameters(self) -> int:
        n = sum(p.numel() for p in self.encoder.parameters())
        if self.head_type == "ddpg":
            n += sum(p.numel() for p in self.head.actor.parameters())
            n += sum(p.numel() for p in self.head.critic.parameters())
        return n
