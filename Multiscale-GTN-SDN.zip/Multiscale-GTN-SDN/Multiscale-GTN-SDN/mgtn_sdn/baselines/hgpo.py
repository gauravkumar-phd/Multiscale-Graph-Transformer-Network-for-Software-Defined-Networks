"""HGPO [21] — Hierarchical Genetic Parameter Optimisation with federated
aggregation (re-implemented from Fallah et al., Mobile Inf. Syst. 2023;
adapted variant).

Native method: federated-learning clients train local models; a genetic
algorithm optimises load balancing; a central aggregator combines clients.
Adaptation for the common task: each controller domain is an FL client that
evolves a population of linear path-scoring policies
    score_k = theta . f_k ,   split = softmax(score / tau) over valid paths
with GA (tournament selection, uniform crossover, Gaussian mutation) using
the cumulative per-request reward as fitness; every ``agg_period`` episodes
the aggregator FedAvg-merges the clients' elites into a global policy that is
re-injected into every population.
"""
from __future__ import annotations

import copy

import numpy as np

from ..agent import RoutingPolicy
from .common import domains, project

F_DIM = 5


class HGPO(RoutingPolicy):
    name = "HGPO"

    def __init__(self, population: int = 16, mutation_sigma: float = 0.2, crossover_rate: float = 0.7,
                 agg_period: int = 2, tau: float = 0.2, max_clients: int = 4, seed: int = 0, **_):
        self.pop, self.sig, self.cx = int(population), mutation_sigma, crossover_rate
        self.agg, self.tau, self.max_clients = int(agg_period), tau, int(max_clients)
        self.rng = np.random.default_rng(seed)
        self.seed = seed
        self.clients = None
        self._ep = 0

    def begin_topology(self, sim):
        self.dom = np.minimum(domains(sim, self.seed, self.max_clients), self.max_clients - 1)
        if self.clients is None:
            prior = np.array([0, 1, 1, -1, -3], dtype=float)     # sensible init, then evolved
            self.clients = [dict(P=prior + self.rng.normal(0, 0.5, (self.pop, F_DIM)),
                                 fit=np.zeros(self.pop), cnt=np.zeros(self.pop), i=0)
                            for _ in range(self.max_clients)]
            self.global_theta = prior.copy()

    def _policy(self, theta, pf, mask):
        z = pf @ theta / self.tau
        z = np.where(mask > 0, z, -1e9)
        e = np.exp(z - z.max()) * mask
        return e / e.sum()

    def act(self, sim, req, train):
        mask = sim.mask(req.src, req.dst)
        pf = sim.path_features(req.src, req.dst, req.demand)
        c = self.clients[self.dom[req.src]]
        if train:
            idx = c["i"] % self.pop
            c["i"] += 1
            self._cur = (c, idx)
            return project(self._policy(c["P"][idx], pf, mask), mask)
        theta = c.get("elite", self.global_theta)
        return project(self._policy(theta, pf, mask), mask)

    def observe(self, sim, reward, done, train):
        if train:
            c, idx = self._cur
            c["fit"][idx] += reward
            c["cnt"][idx] += 1

    def _evolve(self, c):
        fit = c["fit"] / np.maximum(c["cnt"], 1)
        order = np.argsort(-fit)
        c["elite"] = c["P"][order[0]].copy()
        new = [c["P"][order[0]].copy()]
        while len(new) < self.pop:
            a, b = [max(self.rng.choice(self.pop, 3, replace=False), key=lambda j: fit[j]) for _ in range(2)]
            child = c["P"][a].copy()
            if self.rng.random() < self.cx:
                m = self.rng.random(F_DIM) < 0.5
                child[m] = c["P"][b][m]
            child += self.rng.normal(0, self.sig, F_DIM)
            new.append(child)
        c["P"] = np.array(new)
        c["fit"][:] = 0; c["cnt"][:] = 0

    def end_episode(self):
        self._ep += 1
        for c in self.clients:
            if c["cnt"].sum() > 0:
                self._evolve(c)
        if self._ep % self.agg == 0:                                 # federated aggregation
            elites = [c["elite"] for c in self.clients if "elite" in c]
            if elites:
                self.global_theta = np.mean(elites, 0)
                for c in self.clients:
                    c["P"][-1] = self.global_theta

    def state_dict(self):
        return {"clients": copy.deepcopy(self.clients), "global": self.global_theta.copy()}

    def load_state_dict(self, sd):
        self.clients = copy.deepcopy(sd["clients"])
        self.global_theta = sd["global"].copy()
