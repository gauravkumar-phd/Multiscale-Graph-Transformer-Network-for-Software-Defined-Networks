from .cahpo import CAHPO
from .d2dqn import D2DQN
from .derfdrl import DERFDRL
from .dsenn import DSENN
from .hgpo import HGPO

REGISTRY = {"cahpo": CAHPO, "d2dqn": D2DQN, "hgpo": HGPO, "dsenn": DSENN, "derfdrl": DERFDRL}

__all__ = ["CAHPO", "D2DQN", "HGPO", "DSENN", "DERFDRL", "REGISTRY"]
