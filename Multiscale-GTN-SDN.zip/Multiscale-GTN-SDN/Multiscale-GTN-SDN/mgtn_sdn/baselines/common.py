"""Shared helpers for the re-implemented baselines."""
from __future__ import annotations

from typing import Dict, List

import networkx as nx
import numpy as np

from ..simulator import SDNSimulator, mm1k
from ..traffic import Request

# Discrete split templates used by value-based agents (D2DQN)
TEMPLATES = np.array([
    [1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1],
    [.5, .5, 0, 0], [1 / 3, 1 / 3, 1 / 3, 0], [.25, .25, .25, .25], [.4, .3, .2, .1],
], dtype=np.float32)


def project(split: np.ndarray, mask: np.ndarray) -> np.ndarray:
    s = np.clip(split, 0, None) * mask
    return s / s.sum() if s.sum() > 0 else mask / max(mask.sum(), 1)


def domains(sim: SDNSimulator, seed: int, max_domains: int = 8) -> np.ndarray:
    """Partition switches into controller domains (Louvain communities,
    merged down to at most ``max_domains``)."""
    comms = nx.community.louvain_communities(sim.topo.graph, seed=seed)
    comms = sorted(comms, key=len, reverse=True)
    lab = np.zeros(sim.n, dtype=int)
    for i, c in enumerate(comms):
        for v in c:
            lab[v] = min(i, max_domains - 1)
    return lab


class SplitEvaluator:
    """Analytic what-if evaluation of many candidate splits for one request:
    returns split-weighted path delay (ms) and loss (fraction) after placing
    the request, using the same M/M/1/K link model as the simulator."""

    def __init__(self, sim: SDNSimulator, req: Request):
        self.sim, self.req = sim, req
        pl = sim.path_link_idx(req.src, req.dst)
        self.kp = len(pl)
        self.U = np.unique(np.concatenate(pl)) if pl else np.array([], int)
        pos = {l: i for i, l in enumerate(self.U)}
        self.M = np.zeros((sim.k, len(self.U)))
        for k, li in enumerate(pl):
            self.M[k, [pos[l] for l in li]] = 1
        self.base = sim.load[self.U]
        self.cap = sim.cap[self.U]
        self.prop = sim.prop[self.U]

    def evaluate(self, splits: np.ndarray):
        splits = np.atleast_2d(splits)
        load = self.base[None, :] + self.req.demand * splits @ self.M          # (P, U)
        rho = load / self.cap[None, :]
        P, L = mm1k(rho, self.sim.K)
        mu = self.cap * 1e6 / self.sim.pkt_bits
        W = np.where(rho > 0, L / np.maximum(rho * mu * (1 - P), 1e-9) * 1e3, 1e3 / mu)
        pdelay = (self.prop[None, :] + W) @ self.M.T                             # (P, K)
        ploss = 1 - np.exp(np.log(np.clip(1 - P, 1e-12, 1)) @ self.M.T)
        delay = (splits * pdelay).sum(1)
        loss = (splits * ploss).sum(1)
        return delay, loss, rho


def feature_state(sim: SDNSimulator, req: Request, dmax: float) -> np.ndarray:
    pf = sim.path_features(req.src, req.dst, req.demand).ravel()
    rho = sim.rho
    return np.concatenate([pf, [req.demand / dmax, float(np.minimum(rho, 1).mean()),
                                float(np.minimum(rho, 1).max())]]).astype(np.float32)
