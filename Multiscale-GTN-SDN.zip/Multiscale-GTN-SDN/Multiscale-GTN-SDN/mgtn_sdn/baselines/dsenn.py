"""DSENN [22] — collaborative multi-domain routing with a central broker
(re-implemented from Moufakir et al., J. Netw. Syst. Manage. 2021; adapted
variant; label 'DSENN' kept as in the manuscript).

Native method: domain controllers share only abstract path information
(bandwidth, delay, cost) with a broker, which selects inter-domain routes
satisfying bandwidth/delay requirements.
Adaptation for the common task: controllers publish per-domain abstract
state (mean delay, max utilisation, cost) every ``update_interval``
requests (stale between updates, as in the native protocol); the broker
scores each Yen candidate with
    cost_k = alpha * delay_k + beta * util_k + gamma * domains_crossed_k
from the abstracted view and splits traffic by softmin(cost / T).
"""
from __future__ import annotations

import numpy as np

from ..agent import RoutingPolicy
from .common import domains, project


class DSENN(RoutingPolicy):
    name = "DSENN"

    def __init__(self, alpha: float = 1.0, beta: float = 2.0, gamma: float = 0.2, temperature: float = 0.3,
                 update_interval: int = 20, seed: int = 0, **_):
        self.a, self.b, self.g, self.T = alpha, beta, gamma, temperature
        self.ui = int(update_interval)
        self.seed = seed

    def begin_topology(self, sim):
        self.dom = domains(sim, self.seed)
        self.link_dom = self.dom[sim.src_node]
        self.nd = self.dom.max() + 1
        self._t = 0
        self._publish(sim)

    def _publish(self, sim):
        rho, P, W = sim.link_state()
        u = np.minimum(rho, 1)
        c = np.maximum(np.bincount(self.link_dom, minlength=self.nd), 1)
        self.d_delay = np.bincount(self.link_dom, weights=sim.prop + W, minlength=self.nd) / c
        self.d_util = np.zeros(self.nd)
        np.maximum.at(self.d_util, self.link_dom, u)

    def act(self, sim, req, train):
        if self._t % self.ui == 0:
            self._publish(sim)
        self._t += 1
        mask = sim.mask(req.src, req.dst)
        cost = np.full(sim.k, 1e9)
        for i, li in enumerate(sim.path_link_idx(req.src, req.dst)):
            ld = self.link_dom[li]
            cost[i] = (self.a * self.d_delay[ld].sum() / 20.0 + self.b * self.d_util[ld].max()
                       + self.g * len(np.unique(ld)))
        z = -cost / self.T
        z = np.where(mask > 0, z, -1e9)
        e = np.exp(z - z.max()) * mask
        return project(e / e.sum(), mask)
