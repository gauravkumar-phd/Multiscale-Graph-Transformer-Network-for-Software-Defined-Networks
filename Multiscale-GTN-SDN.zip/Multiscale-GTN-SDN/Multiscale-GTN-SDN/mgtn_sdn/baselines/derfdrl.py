"""DERFDRL [23] — priority-based energy- and load-aware routing with
federated deep RL (re-implemented from Pathan et al., Computer Networks 2024;
adapted variant).

Native method: MILP for optimal energy/load-aware routing plus two greedy
heuristics — PEDL (priority-based evenly load distribution) and PEMA
(priority-based energy minimisation) — for SDN data-centre networks.
Adaptation for the common task: the MILP is intractable per request at
1000 nodes, so the PEDL and PEMA scores are used as *features* of
per-domain DDPG agents (actor-critic MLPs, same K = 4 continuous split action)
whose parameters are FedAvg-aggregated every ``agg_period`` episodes. The
reward adds an energy term penalising newly activated links (lambda_e).
Flow priority = demand quantile (high demand -> high priority).
"""
from __future__ import annotations

import copy

import numpy as np
import torch

from ..agent import RoutingPolicy
from ..rl.ddpg import DDPGHead
from ..rl.replay import ReplayBuffer
from .common import domains, project


class DERFDRL(RoutingPolicy):
    name = "DERFDRL"

    def __init__(self, lr: float = 1e-3, gamma: float = 0.95, sigma0: float = 0.2, sigma_decay: float = 0.995,
                 local_updates: int = 1, agg_period: int = 2, lambda_e: float = 0.1, max_clients: int = 3,
                 batch: int = 64, buffer: int = 20000, demand_max: float = 60.0, update_every: int = 4,
                 seed: int = 0, **_):
        torch.manual_seed(seed)
        self.s_dim = 4 * 5 + 4 + 4 + 2
        cfg = dict(lr=lr, gamma=gamma, sigma0=sigma0, sigma_decay=sigma_decay, hidden=(128, 64))
        self.nc = int(max_clients)
        self.agents = [DDPGHead(self.s_dim, 4, cfg, seed + i) for i in range(self.nc)]
        self.bufs = [ReplayBuffer(int(buffer), self.s_dim, 4, seed + i) for i in range(self.nc)]
        self.local_updates, self.agg, self.lam = int(local_updates), int(agg_period), lambda_e
        self.batch, self.dmax, self.update_every = int(batch), demand_max, int(update_every)
        self.seed = seed
        self._ep = self._t = 0
        self._prev = [None] * self.nc

    def begin_topology(self, sim):
        self.dom = np.minimum(domains(sim, self.seed, self.nc), self.nc - 1)

    def _state(self, sim, req):
        pf = sim.path_features(req.src, req.dst, req.demand)
        active = sim.load > 1e-9
        pedl, pema = np.zeros(4), np.zeros(4)
        for i, li in enumerate(sim.path_link_idx(req.src, req.dst)):
            pedl[i] = 1 - np.minimum(sim.rho[li], 1).max()          # even load: low max utilisation
            pema[i] = active[li].mean()                              # energy: reuse active links
        prio = req.demand / self.dmax
        return np.concatenate([pf.ravel(), pedl, pema, [prio, float(active.mean())]]).astype(np.float32), active

    def act(self, sim, req, train):
        c = self.dom[req.src]
        s, active = self._state(sim, req)
        mask = sim.mask(req.src, req.dst)
        ag = self.agents[c]
        with torch.no_grad():
            a = ag.actor(torch.from_numpy(s)[None], torch.from_numpy(mask)[None])[0].numpy()
        if train:
            a = ag.explore(a, mask)
            if self._prev[c] is not None:
                ps, pm, pa, pr = self._prev[c]
                self.bufs[c].add(ps, pm, pa, pr, s, mask, 0.0)
            self._cur = (c, s, mask, a, active.copy())
        return project(a, mask)

    def observe(self, sim, reward, done, train):
        if not train:
            return
        c, s, mask, a, before = self._cur
        newly = ((sim.load > 1e-9) & ~before).sum() / max(len(before), 1)
        r = reward - self.lam * newly * 10                              # energy-aware reward
        if done:
            self.bufs[c].add(s, mask, a, r, np.zeros_like(s), np.zeros_like(mask), 1.0)
            self._prev[c] = None
        else:
            self._prev[c] = (s, mask, a, r)
        self._t += 1
        if self._t % self.update_every == 0 and len(self.bufs[c]) >= self.batch:
            for _ in range(self.local_updates):
                self.agents[c].update(self.bufs[c].sample(self.batch))

    def end_episode(self):
        self._ep += 1
        for ag in self.agents:
            ag.end_episode()
        self._prev = [None] * self.nc
        if self._ep % self.agg == 0:                                    # FedAvg
            for part in ("actor", "critic", "actor_t", "critic_t"):
                sds = [getattr(ag, part).state_dict() for ag in self.agents]
                avg = {k: torch.stack([sd[k] for sd in sds]).mean(0) for k in sds[0]}
                for ag in self.agents:
                    getattr(ag, part).load_state_dict(avg)

    def state_dict(self):
        return {"agents": [copy.deepcopy(a.state_dict()) for a in self.agents]}

    def load_state_dict(self, sd):
        for a, s in zip(self.agents, sd["agents"]):
            a.load_state_dict(s)
