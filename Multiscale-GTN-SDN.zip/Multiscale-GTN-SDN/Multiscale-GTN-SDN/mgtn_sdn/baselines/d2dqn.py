"""D2DQN [20] — Dual Double Deep Q-Network (re-implemented from Gilliard
et al., Trans. Emerging Telecom. Tech. 2024; adapted variant).

Native method: two DQN learners for elephant and mice flows in a data-centre
SDN, choosing routes from bandwidth usage and switch load.
Adaptation for the common task: elephant/mice classification by a tunable
demand threshold; each learner is a Double DQN whose discrete action picks
one of 8 split templates over the K = 4 candidate paths (4 single-path
choices + 4 multipath templates); invalid templates are masked. Q-networks
are MLPs over candidate-path telemetry.
"""
from __future__ import annotations

import copy

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from ..agent import RoutingPolicy
from .common import TEMPLATES, feature_state, project


class _QNet(nn.Module):
    def __init__(self, d, a):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(d, 128), nn.ReLU(), nn.Linear(128, 64), nn.ReLU(), nn.Linear(64, a))

    def forward(self, x):
        return self.net(x)


class D2DQN(RoutingPolicy):
    name = "D2DQN"

    def __init__(self, lr: float = 1e-3, gamma: float = 0.95, buffer: int = 20000, batch: int = 64,
                 target_interval: int = 200, eps_start: float = 1.0, eps_end: float = 0.05,
                 eps_decay: float = 0.995, elephant_threshold: float = 40.0, demand_max: float = 60.0,
                 update_every: int = 4, seed: int = 0, **_):
        torch.manual_seed(seed)
        self.rng = np.random.default_rng(seed)
        self.d = 4 * 5 + 3
        self.A = len(TEMPLATES)
        self.q = [_QNet(self.d, self.A), _QNet(self.d, self.A)]          # [mice, elephant]
        self.qt = [copy.deepcopy(q) for q in self.q]
        self.opt = [torch.optim.Adam(q.parameters(), lr=lr) for q in self.q]
        self.gamma, self.batch, self.tint = gamma, int(batch), int(target_interval)
        self.eps, self.eps_end, self.eps_decay = eps_start, eps_end, eps_decay
        self.thr, self.dmax, self.update_every = elephant_threshold, demand_max, int(update_every)
        cap = int(buffer)
        self.buf = [dict(s=np.zeros((cap, self.d), np.float32), a=np.zeros(cap, np.int64),
                         r=np.zeros(cap, np.float32), s2=np.zeros((cap, self.d), np.float32),
                         m2=np.zeros((cap, self.A), np.float32), d=np.zeros(cap, np.float32),
                         n=0, p=0, cap=cap) for _ in range(2)]
        self._prev = None
        self._t = 0

    def _valid(self, mask):
        return ((TEMPLATES * (1 - mask)).sum(1) == 0).astype(np.float32)

    def act(self, sim, req, train):
        s = feature_state(sim, req, self.dmax)
        mask = sim.mask(req.src, req.dst)
        valid = self._valid(mask)
        c = int(req.demand >= self.thr)
        if train and self._prev is not None:
            self._store(*self._prev, s, valid, 0.0)
        if train and self.rng.random() < self.eps:
            a = int(self.rng.choice(np.flatnonzero(valid)))
        else:
            with torch.no_grad():
                qv = self.q[c](torch.from_numpy(s)).numpy()
            a = int(np.argmax(np.where(valid > 0, qv, -1e9)))
        self._cur = (c, s, a)
        return project(TEMPLATES[a], mask)

    def _store(self, c, s, a, r, s2, m2, d):
        b = self.buf[c]
        i = b["p"]
        b["s"][i], b["a"][i], b["r"][i], b["s2"][i], b["m2"][i], b["d"][i] = s, a, r, s2, m2, d
        b["p"] = (i + 1) % b["cap"]; b["n"] = min(b["n"] + 1, b["cap"])

    def observe(self, sim, reward, done, train):
        if not train:
            return
        c, s, a = self._cur
        if done:
            self._store(c, s, a, reward, np.zeros_like(s), np.ones(self.A, np.float32), 1.0)
            self._prev = None
        else:
            self._prev = (c, s, a, reward)
        self._t += 1
        self.eps = max(self.eps_end, self.eps * self.eps_decay)          # per-step epsilon decay
        if self._t % self.update_every:
            return
        for k in range(2):
            b = self.buf[k]
            if b["n"] < self.batch:
                continue
            idx = self.rng.integers(0, b["n"], self.batch)
            S, A_, R = map(torch.from_numpy, (b["s"][idx], b["a"][idx], b["r"][idx]))
            S2, M2, D = map(torch.from_numpy, (b["s2"][idx], b["m2"][idx], b["d"][idx]))
            with torch.no_grad():                                        # Double DQN target
                a2 = self.q[k](S2).masked_fill(M2 <= 0, -1e9).argmax(1, keepdim=True)
                y = R + self.gamma * (1 - D) * self.qt[k](S2).gather(1, a2).squeeze(1)
            loss = F.smooth_l1_loss(self.q[k](S).gather(1, A_.unsqueeze(1)).squeeze(1), y)
            self.opt[k].zero_grad(); loss.backward(); self.opt[k].step()
        if self._t % self.tint == 0:
            for k in range(2):
                self.qt[k].load_state_dict(self.q[k].state_dict())

    def end_episode(self):
        self._prev = None

    def state_dict(self):
        return {"q": [copy.deepcopy(q.state_dict()) for q in self.q]}

    def load_state_dict(self, sd):
        for q, s in zip(self.q, sd["q"]):
            q.load_state_dict(s)
