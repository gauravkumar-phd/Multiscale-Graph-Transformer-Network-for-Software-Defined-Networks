"""CAHPO [19] — Congestion-Aware Hierarchical Particle (swarm) Optimisation
(re-implemented from Azizi et al., Computing 2025; adapted variant).

Native method: hierarchical PSO where domain-level controllers track
congestion and a PSO optimises bandwidth allocation / routing paths with a
delay + congestion fitness.
Adaptation for the common task: particles encode the K = 4 split ratios of
the current request (softmax of particle positions over valid candidates);
the fitness is the analytic post-placement delay + loss + domain-congestion
penalty; the upper (domain) level refreshes per-domain congestion every
``domain_update`` requests. No gradient learning — only the PSO parameters
are tuned.
"""
from __future__ import annotations

import numpy as np

from ..agent import RoutingPolicy
from .common import SplitEvaluator, domains


class CAHPO(RoutingPolicy):
    name = "CAHPO"

    def __init__(self, swarm: int = 20, inertia: float = 0.7, c1: float = 1.5, c2: float = 1.5,
                 vmax: float = 0.5, iters: int = 10, w_cong: float = 0.3, domain_update: int = 25,
                 seed: int = 0, **_):
        self.p = dict(swarm=int(swarm), inertia=inertia, c1=c1, c2=c2, vmax=vmax, iters=int(iters),
                      w_cong=w_cong, domain_update=int(domain_update))
        self.rng = np.random.default_rng(seed)
        self.seed = seed

    def begin_topology(self, sim):
        self.dom = domains(sim, self.seed)
        self.link_dom = self.dom[sim.src_node]
        self.cong = np.zeros(self.dom.max() + 1)
        self._t = 0

    def _update_domains(self, sim):
        util = np.minimum(sim.rho, 1)
        s = np.bincount(self.link_dom, weights=util, minlength=len(self.cong))
        c = np.bincount(self.link_dom, minlength=len(self.cong))
        self.cong = s / np.maximum(c, 1)

    def act(self, sim, req, train):
        if self._t % self.p["domain_update"] == 0:
            self._update_domains(sim)
        self._t += 1
        mask = sim.mask(req.src, req.dst)
        paths = sim.paths(req.src, req.dst)
        pen = np.zeros(sim.k)
        for i, p in enumerate(paths):
            pen[i] = self.cong[np.unique(self.dom[p])].mean()
        ev = SplitEvaluator(sim, req)
        S, K = self.p["swarm"], sim.k
        x = self.rng.normal(0, 1, (S, K))
        v = self.rng.uniform(-self.p["vmax"], self.p["vmax"], (S, K))

        def split(x):
            z = np.where(mask > 0, x, -1e9)
            e = np.exp(z - z.max(1, keepdims=True)) * mask
            return e / e.sum(1, keepdims=True)

        def fitness(x):
            sp = split(x)
            d, l, _ = ev.evaluate(sp)
            return d / 100.0 + 10 * l + self.p["w_cong"] * (sp * pen).sum(1)

        f = fitness(x)
        pbest, pf = x.copy(), f.copy()
        g = x[f.argmin()].copy(); gf = f.min()
        for _ in range(self.p["iters"]):
            r1, r2 = self.rng.random((S, K)), self.rng.random((S, K))
            v = self.p["inertia"] * v + self.p["c1"] * r1 * (pbest - x) + self.p["c2"] * r2 * (g - x)
            v = np.clip(v, -self.p["vmax"], self.p["vmax"])
            x = x + v
            f = fitness(x)
            imp = f < pf
            pbest[imp], pf[imp] = x[imp], f[imp]
            if f.min() < gf:
                g, gf = x[f.argmin()].copy(), f.min()
        return split(g[None])[0].astype(np.float32)

    def state_dict(self):
        return {}
