"""Candidate-path generation with Yen's K-shortest loop-free paths.

networkx.shortest_simple_paths implements Yen's algorithm; simple paths are
loop-free by construction, which is what guarantees routing-loop freedom in
the action space. Paths are cached per (src, dst) because the topology is
static within an episode (it only changes in the link-failure experiment,
where a fresh cache is built).
"""
from __future__ import annotations

from itertools import islice
from typing import Dict, List, Tuple

import networkx as nx
import numpy as np


class CandidatePaths:
    def __init__(self, graph: nx.Graph, k: int = 4, weight: str | None = None):
        self.g = graph
        self.k = k
        self.weight = weight
        self._cache: Dict[Tuple[int, int], List[List[int]]] = {}

    def get(self, src: int, dst: int) -> List[List[int]]:
        key = (src, dst)
        if key not in self._cache:
            try:
                paths = list(islice(nx.shortest_simple_paths(self.g, src, dst, weight=self.weight), self.k))
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                paths = []
            self._cache[key] = paths
        return self._cache[key]

    def mask(self, src: int, dst: int) -> np.ndarray:
        """Lookup mask: 1 for an available candidate, 0 for a padded slot."""
        m = np.zeros(self.k, dtype=np.float32)
        m[: len(self.get(src, dst))] = 1.0
        return m


def path_links(path: List[int]) -> List[Tuple[int, int]]:
    return list(zip(path[:-1], path[1:]))
