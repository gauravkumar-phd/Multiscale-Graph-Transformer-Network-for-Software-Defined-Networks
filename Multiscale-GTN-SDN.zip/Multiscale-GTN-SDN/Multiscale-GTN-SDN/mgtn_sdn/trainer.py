"""Training / evaluation loops, model selection and the experiment runner
shared by every script.

Seed protocol (identical for every method)
    run seed s in {42, 128, 256, 512, 728}
    topology         generated with seed s
    torch / numpy    seeded with s
    training traffic episode e uses traffic seed 1000*s + e
    test traffic     traffic seed 1000*s + 999   (never seen in training)
    validation       traffic seed 1000*s + 998   (tuning only)

Model selection
    highest rolling mean episode reward (window 5); stop after 10 episodes
    without improvement (patience) or after E_max episodes.

Execution-time boundary (per routing decision, Sec. 'Execution-Time and
Energy Measurement Methodology')
    starts   when the request/telemetry observation reaches the controller
    includes state preprocessing, encoder inference, action selection,
             candidate-path evaluation, bucket-weight (forwarding) decision
    excludes packet transmission and switch forwarding (simulator step)
    clock    time.perf_counter_ns (monotonic, high resolution)
"""
from __future__ import annotations

import copy
import time
from typing import Callable, Dict, List, Optional

import numpy as np
import torch

from .agent import RoutingPolicy, bucket_weights
from .simulator import SDNSimulator, reward_from_metrics
from .topology import Topology
from .traffic import make_traffic


def run_episode(policy: RoutingPolicy, sim: SDNSimulator, train: bool, reward_w, norm,
                timings: Optional[List[float]] = None) -> Dict[str, float]:
    sim.reset()
    total_r = 0.0
    while True:
        req = sim.current_request()
        if req is None:
            break
        t0 = time.perf_counter_ns()
        split = policy.act(sim, req, train)
        mask = sim.mask(req.src, req.dst)
        split = split * mask
        split = split / split.sum() if split.sum() > 0 else mask / max(mask.sum(), 1)
        _ = bucket_weights(split)                                   # forwarding decision
        t1 = time.perf_counter_ns()
        if timings is not None:
            timings.append((t1 - t0) / 1e6)
        m, done = sim.step(split)
        r = reward_from_metrics(m, reward_w, norm)
        total_r += r
        policy.observe(sim, r, done, train)
        if done:
            break
    policy.end_episode()
    out = sim.summary()
    out["reward"] = total_r
    return out


def train_policy(policy: RoutingPolicy, topo: Topology, cfg: dict, seed: int,
                 log: Optional[Callable[[str], None]] = None) -> List[Dict[str, float]]:
    sc, tc = cfg["simulation"], cfg["training"]
    norm = sc.get("reward_norm")
    w = tuple(cfg["reward"]["weights"])
    torch.manual_seed(seed); np.random.seed(seed)
    window, patience = tc.get("selection_window", 5), tc.get("patience", 10)
    best, best_sd, since, hist = -np.inf, None, 0, []
    for e in range(tc["episodes"]):
        reqs = make_traffic(sc["traffic"], topo.n, sc["requests_per_episode"], 1000 * seed + e,
                            **sc.get("traffic_kw", {}))
        sim = SDNSimulator(topo, reqs, k_paths=sc["k_paths"], buffer_pkts=sc["buffer_pkts"],
                           loss_break=sc.get("loss_break", 0.5))
        if e == 0:
            policy.begin_topology(sim)
        res = run_episode(policy, sim, True, w, norm)
        res["episode"] = e
        hist.append(res)
        roll = float(np.mean([h["reward"] / max(h["steps"], 1) for h in hist[-window:]]))
        if roll > best + 1e-9:
            best, best_sd, since = roll, policy.state_dict(), 0
        else:
            since += 1
        if log:
            log(f"  ep {e:3d} steps {res['steps']:5d} loss {res['packet_loss']:.3f}% "
                f"delay {res['delay']:.2f}ms thr {res['throughput']:.2f} rolling_R {roll:.4f}")
        if since >= patience:
            break
    if best_sd is not None:
        policy.load_state_dict(best_sd)
    return hist


def evaluate_policy(policy: RoutingPolicy, topo: Topology, cfg: dict, seed: int,
                    traffic: Optional[str] = None, traffic_seed: Optional[int] = None,
                    reinit_topology: bool = False) -> Dict[str, float]:
    sc = cfg["simulation"]
    kind = traffic or sc["traffic"]
    reqs = make_traffic(kind, topo.n, sc["eval_requests"],
                        traffic_seed if traffic_seed is not None else 1000 * seed + 999,
                        **sc.get("traffic_kw", {}))
    sim = SDNSimulator(topo, reqs, k_paths=sc["k_paths"], buffer_pkts=sc["buffer_pkts"], loss_break=None)
    policy.begin_topology(sim)   # structural pools for this (possibly unseen) topology; no training
    timings: List[float] = []
    torch.manual_seed(seed)
    with torch.no_grad():
        res = run_episode(policy, sim, False, tuple(cfg["reward"]["weights"]), sc.get("reward_norm"), timings)
    t = np.array(timings[sc.get("warmup_steps", 20):]) if len(timings) > sc.get("warmup_steps", 20) else np.array(timings)
    res["exec_ms"] = float(t.mean()) if len(t) else float("nan")
    res["exec_ms_std"] = float(t.std()) if len(t) else float("nan")
    return res
