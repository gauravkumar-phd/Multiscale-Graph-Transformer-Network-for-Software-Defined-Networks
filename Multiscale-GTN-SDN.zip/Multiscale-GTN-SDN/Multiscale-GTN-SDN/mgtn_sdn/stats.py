"""Inferential statistics for run-level results (reviewer comments on
statistical support).

For each metric and each baseline B, runs are PAIRED: run i of the proposed
model and run i of B share the same seed, topology instance and traffic
trace (the pairing subject). We report
    descriptive  N, mean, median, SD, 95 % t-based CI of the mean
    paired test  paired two-sided t-test on d_i = proposed_i - B_i
    robustness   Wilcoxon signed-rank test (non-parametric)
    multiplicity Holm step-down correction across the baselines compared
    effect size  Cohen's d_z = mean(d) / SD(d)  and Hedges' g_av
    CI of diff   95 % t-based CI of mean(d)
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np
import pandas as pd
from scipy import stats


def describe(x: np.ndarray, conf: float = 0.95) -> Dict[str, float]:
    x = np.asarray(x, float)
    n = len(x)
    m, sd = x.mean(), x.std(ddof=1) if n > 1 else 0.0
    h = stats.t.ppf((1 + conf) / 2, n - 1) * sd / np.sqrt(n) if n > 1 else np.nan
    return {"N": n, "Mean": m, "Median": float(np.median(x)), "Std": sd, "CI_low": m - h, "CI_high": m + h}


def holm(pvals: List[float], alpha: float = 0.05):
    """Holm step-down: returns (thresholds, adjusted p, reject) in input order."""
    p = np.asarray(pvals, float)
    m = len(p)
    order = np.argsort(p)
    thr, adj, rej = np.empty(m), np.empty(m), np.zeros(m, bool)
    running, still = 0.0, True
    for rank, i in enumerate(order):
        thr[i] = alpha / (m - rank)
        running = max(running, min(1.0, (m - rank) * p[i]))
        adj[i] = running
        still = still and p[i] <= thr[i]
        rej[i] = still
    return thr, adj, rej


def paired_comparison(proposed: np.ndarray, baselines: Dict[str, np.ndarray], label: str = "Proposed",
                      higher_is_better: bool = True, alpha: float = 0.05) -> pd.DataFrame:
    rows = []
    for name, b in baselines.items():
        d = np.asarray(proposed, float) - np.asarray(b, float)
        n = len(d)
        md, sdd = d.mean(), d.std(ddof=1)
        t, p = stats.ttest_rel(proposed, b)
        try:
            w_p = stats.wilcoxon(proposed, b).pvalue
        except ValueError:
            w_p = np.nan
        h = stats.t.ppf(0.975, n - 1) * sdd / np.sqrt(n)
        sd_av = np.sqrt((np.var(proposed, ddof=1) + np.var(b, ddof=1)) / 2)
        g = (md / sd_av) * (1 - 3 / (4 * (2 * n - 2) - 1)) if sd_av > 0 else np.nan
        rows.append({"Compared Model": f"{label} vs {name}", "N pairs": n, "Mean Diff": md, "SD Diff": sdd,
                     "95% CI Diff": f"[{md - h:.4g}, {md + h:.4g}]", "t-value": t, "p-value (t-test)": p,
                     "p-value (Wilcoxon)": w_p, "Cohen's d_z": md / sdd if sdd > 0 else np.nan,
                     "Hedges' g_av": g})
    df = pd.DataFrame(rows)
    thr, adj, rej = holm(df["p-value (t-test)"].tolist(), alpha)
    df["Holm Threshold"] = thr
    df["P-Holm"] = adj
    better = df["Mean Diff"] > 0 if higher_is_better else df["Mean Diff"] < 0
    df["Holm reject H0"] = np.where(rej, "Yes", "No")                    # two-sided, either direction
    df["Direction"] = np.where(better, "proposed better", "proposed worse")
    df["Significant"] = np.where(rej & better, "Yes", "No")             # proposed significantly better
    return df


def descriptive_table(runs: Dict[str, np.ndarray]) -> pd.DataFrame:
    rows = []
    for k, v in runs.items():
        d = describe(v)
        rows.append({"Model": k, "N": d["N"], "Mean": d["Mean"], "Median": d["Median"], "Std": d["Std"],
                     "95% CI": f"[{d['CI_low']:.2f}, {d['CI_high']:.2f}]"})
    return pd.DataFrame(rows)
